QUANTUM HAMLETS - JRPG FIGURE VARIANTS
Created 11 November 2026

Three coordinated 16-bit JRPG-inspired illustration variants:

01_hamlets_overview.png - Alternative to Figure 1.
Three hamlets, three villagers and one mayor per hamlet; dashed routes are
network availability, not simultaneous Bell pairs. 1642 x 958 pixels.

02_vcg_protocol.png - Alternative to Figure 2.
Four panels separate Bell-pair preparation, local attachment and the two
corrected measurements. The seven-edge intermediate graph and final
three-edge star have been visually checked. 1536 x 1024 pixels.
This version explicitly includes the measurement-correction convention
identified in the earlier manuscript review; use its supplied caption.

03_bury_first_step.png - Alternative to Figure 3.
The before/after grids each retain 16 nodes and 24 edges. All weights match
the first BURY step; exactly three vertices are assigned, with capacity
8 -> 5. Infinity is a processed-node sentinel, not a neighborhood cost.
1642 x 958 pixels.

USAGE
Use at full two-column width for readable labels. These are raster pixel-art
illustrations, not vector redrawings. PDF preview pages embed the same PNGs.
figures.tex contains suggested LaTeX inclusions and complete captions.
The snippet uses the manuscript's existing ket command; retain braket.
The source manuscript and numerical result plots were not modified.

DESIGN CHOICES
The hamlet, protocol and algorithm diagrams are suitable for the JRPG visual
metaphor. Numerical plots retain their conventional visual language because
their axes, marker geometry and error bars carry quantitative evidence.
The existing METIS/BURY grid example remains a useful exact comparison.

PROVENANCE
Created with the built-in image_gen tool. Exact generation prompts are in
generation_prompts.json; the focused VCG geometry correction is recorded in
vcg_refinement_prompt.json. No new numerical results were generated.

PAPER INTEGRATION
These files are proposed alternatives, not edits to the manuscript. The
captions distinguish hardware connections from state edges and specify
measurement corrections.
