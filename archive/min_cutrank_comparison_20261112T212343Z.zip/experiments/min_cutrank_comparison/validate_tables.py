"""Independent table-scorer checks and final published-table consistency checks."""
import argparse
import hashlib
import itertools
import json
import random
import statistics
from collections import defaultdict
from pathlib import Path

from assemble_results import secondary_costs
from run_annealing import table
from validate_upstream import adjacency_from_edges, cut_matching_size


def check_secondary():
    checks = 0
    for n in range(2, 10):
        for seed in range(20):
            rng = random.Random(100 * n + seed)
            edges = [(u, v) for u in range(n) for v in range(u + 1, n) if rng.random() < 0.4]
            adjacency = adjacency_from_edges(n, edges)
            for subset in itertools.combinations(range(n), n // 2):
                flags = [i in subset for i in range(n)]
                matching, cut = secondary_costs(n, edges, flags)
                assert matching == cut_matching_size(adjacency, flags)
                assert cut == sum(flags[u] != flags[v] for u, v in edges)
                checks += 2
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--scorer-only", action="store_true")
    args = parser.parse_args()
    checks = check_secondary()
    details = dict(secondary_scorer_assertions=checks)
    if not args.scorer_only:
        run = args.run_dir
        inputs = table(run / "inputs.tsv")
        protocol = json.loads((run / "protocol.json").read_text())
        for name, field in (("inputs.tsv", "manifest_sha256"), ("baselines.tsv", "baselines_sha256")):
            assert hashlib.sha256((run / name).read_bytes()).hexdigest() == protocol[field]
            checks += 1
        rows, summaries = table(run / "results.tsv"), table(run / "summary.tsv")
        assert len(rows) == 13735 and len(summaries) == 1675
        checks += 2
        unique = table(run / "memberships.tsv")
        indexed = {r["membership_id"]: r for r in unique}
        assert len(indexed) == len(unique)
        groups = defaultdict(list)
        for row in rows:
            groups[row["id"], row["method"], row["view"], row["budget_seconds"]].append(row)
            if row["rank"]:
                source = indexed[row["membership_id"]]
                for field in ("id", "rank", "matching", "edge_cut"):
                    assert source[field] == row[field]
                    checks += 1
                if row["view"] == "incumbent":
                    assert float(row["candidate_seconds"]) <= float(row["budget_seconds"])
                    checks += 1
        for summary in summaries:
            selected = groups[summary["id"], summary["method"], summary["view"], summary["budget_seconds"]]
            valid = [r for r in selected if r["rank"]]
            assert int(summary["total"]) == len(selected)
            assert int(summary["valid"]) == len(valid)
            checks += 2
            for metric in ("rank", "matching", "edge_cut", "candidate_seconds", "solve_seconds"):
                for suffix, func in (("median", statistics.median), ("min", min), ("max", max)):
                    if valid:
                        assert float(summary[metric + "_" + suffix]) == func(float(r[metric]) for r in valid)
                    else:
                        assert not summary[metric + "_" + suffix]
                    checks += 1
        julia = table(run / "julia_rescoring.tsv")
        assert len(julia) == len(unique)
        checks += 1
        for original, verified in zip(unique, julia):
            assert original["id"] == verified["id"]
            for metric in ("rank", "matching", "edge_cut"):
                assert original[metric] == verified["julia_" + metric]
                checks += 1
        details.update(inputs=len(inputs), result_rows=len(rows), summary_rows=len(summaries),
                       unique_memberships=len(unique), julia_rescored_memberships=len(julia))
    details["total_assertions"] = checks
    target = args.run_dir / ("secondary_scorer_validation.json" if args.scorer_only else "table_validation.json")
    with target.open("x") as handle: json.dump(details, handle, indent=2)
    print(json.dumps(details, indent=2))


if __name__ == "__main__":
    main()
