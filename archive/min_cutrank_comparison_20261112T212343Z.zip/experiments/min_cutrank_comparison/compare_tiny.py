#!/usr/bin/env python3
"""Compare existing BURY methods with exact optima on the validation fixtures.

The ten tiny graphs and the upstream runs are frozen by validate_upstream.py.
This separate sanity suite is not added to main-study counts or runtime claims.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time

from validate_upstream import audit_baselines


HERE = Path(__file__).resolve().parent


def write_table(path, rows):
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def read_table(path):
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def distribution(values, optimum):
    return dict(n=len(values), min=min(values), median=statistics.median(values), max=max(values),
                above_optimum=sum(value > optimum for value in values),
                max_gap=max(values) - optimum)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("main_run_dir", type=Path)
    args = parser.parse_args()
    parent_dir = args.main_run_dir.resolve()
    output = parent_dir / "tiny_bury"
    if output.exists():
        raise SystemExit(f"Refusing to overwrite {output}")
    fixtures_path = parent_dir / "tiny_fixtures.json"
    fixtures = json.loads(fixtures_path.read_text())
    if len(fixtures) != 10:
        raise RuntimeError("Expected the ten pre-existing tiny validation fixtures")
    upstream = read_table(parent_dir / "tiny_exact.tsv")
    if len(upstream) != 100:
        raise RuntimeError("Expected the 100 pre-existing upstream tiny validation runs")
    output.mkdir()
    (output / "edges").mkdir()
    inputs = []
    definitions_hash = hashlib.sha256(fixtures_path.read_bytes()).hexdigest()
    for graph in fixtures:
        edge_path = output / "edges" / (graph["id"] + ".tsv")
        with edge_path.open("x", newline="") as stream:
            writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
            writer.writerow(["u", "v"])
            writer.writerows(sorted(tuple(sorted(edge)) for edge in graph["edges"]))
        inputs.append(dict(
            id=graph["id"], collection="validation_tiny", family="exact_optimum_sanity",
            label=graph["id"], parameter=graph["n"], n=graph["n"], m=len(graph["edges"]),
            source_sha256=definitions_hash,
            edge_sha256=hashlib.sha256(edge_path.read_bytes()).hexdigest(),
        ))
    write_table(output / "inputs.tsv", inputs)
    command = ["julia", "--startup-file=no", "--threads=1", "--project=..",
               str(HERE / "julia_baselines.jl"), "run", str(output)]
    started = time.perf_counter()
    with (output / "julia_output.log").open("x") as stream:
        subprocess.run(command, cwd=HERE.parent.parent, stdout=stream,
                       stderr=subprocess.STDOUT, check=True, timeout=30)
    process_seconds = time.perf_counter() - started
    audit_baselines(output)
    baselines = read_table(output / "baselines.tsv")
    summaries = []
    for graph in fixtures:
        graph_id, optimum = graph["id"], graph["exact_rank"]
        ordinary = [int(row["rank"]) for row in baselines
                    if row["id"] == graph_id and row["method"] == "bury"]
        sampled = [int(row["rank"]) for row in baselines
                   if row["id"] == graph_id and row["method"] == "sqrt_bury"]
        native = [int(row["final_rank"]) for row in upstream if row["id"] == graph_id]
        incumbent = [int(row["incumbent_rank"]) for row in upstream if row["id"] == graph_id]
        if len(ordinary) != 1 or not len(sampled) == len(native) == len(incumbent) == 10:
            raise RuntimeError(f"Missing tiny method/seed coverage: {graph_id}")
        if min(ordinary + sampled + native + incumbent) < optimum:
            raise RuntimeError(f"Saved score below exact optimum: {graph_id}")
        summary = dict(id=graph_id, n=graph["n"], m=len(graph["edges"]), exact_rank=optimum,
                       partitions_enumerated=graph["partitions_enumerated"],
                       bury_rank=ordinary[0], bury_gap=ordinary[0] - optimum)
        for name, values in (("sqrt_bury", sampled), ("upstream_native", native),
                             ("upstream_incumbent", incumbent)):
            summary.update({f"{name}_{field}": value for field, value in distribution(values, optimum).items()})
        summaries.append(summary)
    write_table(output / "tiny_method_summary.tsv", summaries)
    result = dict(
        graphs=len(fixtures), bury_memberships=len(baselines), upstream_runs=len(upstream),
        exact_partitions_enumerated=sum(graph["partitions_enumerated"] for graph in fixtures),
        ordinary_above_optimum=sum(row["bury_gap"] > 0 for row in summaries),
        ordinary_max_gap=max(row["bury_gap"] for row in summaries),
        sqrt_bury_above_optimum=sum(row["sqrt_bury_above_optimum"] for row in summaries),
        sqrt_bury_max_gap=max(row["sqrt_bury_max_gap"] for row in summaries),
        upstream_native_above_optimum=sum(row["upstream_native_above_optimum"] for row in summaries),
        upstream_native_max_gap=max(row["upstream_native_max_gap"] for row in summaries),
        upstream_incumbent_above_optimum=sum(row["upstream_incumbent_above_optimum"] for row in summaries),
        upstream_incumbent_max_gap=max(row["upstream_incumbent_max_gap"] for row in summaries),
        julia_process_seconds=process_seconds,
        fixtures_sha256=definitions_hash,
        upstream_tiny_results_sha256=hashlib.sha256((parent_dir / "tiny_exact.tsv").read_bytes()).hexdigest(),
        quantum_hamlets_commit=subprocess.check_output(
            ["git", "-C", str(HERE.parent.parent), "rev-parse", "HEAD"], text=True).strip(),
        policy="Separate tiny exact-optimum sanity suite, not included in the 67-graph main study. BURY uses the same ordinary and existing matching-selected sqrt-seed policies, with rank outer selection; seeds 0:9 for sqrt BURY. Upstream uses ten sweeps linear 1.0 to 0.1, seeds 0:9. Its tiny-suite random shuffle and annealing use one sequential Python RNG stream; the main study uses separate initialization and annealing streams. No cross-language common-random-number pairing or timing claim.",
    )
    with (output / "tiny_comparison.json").open("x") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
