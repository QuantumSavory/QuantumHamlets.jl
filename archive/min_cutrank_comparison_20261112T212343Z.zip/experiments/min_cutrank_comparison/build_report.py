#!/usr/bin/env python3
"""Build the comparison report from a reviewed JSON content specification.

Use the bundled Codex Python runtime (python-docx and Pillow).  Rendering is a
separate, required step with the documents skill's render_docx.py.  The JSON
specification and this script are retained so the report can be regenerated
without re-running any partitioner.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image


PAGE_WIDTH = 8.5
PAGE_HEIGHT = 11.0
CONTENT_WIDTH = 6.9
FONT = "Arial"


def add_element(parent, name, **attributes):
    node = OxmlElement(name)
    for key, value in attributes.items():
        node.set(qn(key), str(value))
    parent.append(node)
    return node


def add_text(paragraph, text, bold=False):
    """Support restrained bold emphasis without treating prose as Markdown."""
    for index, fragment in enumerate(re.split(r"\*\*(.*?)\*\*", str(text))):
        if fragment:
            run = paragraph.add_run(fragment)
            run.bold = bold or index % 2 == 1


def add_hyperlink(paragraph, label, url):
    rel = paragraph.part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    link = OxmlElement("w:hyperlink")
    link.set(qn("r:id"), rel)
    run = add_element(link, "w:r")
    props = add_element(run, "w:rPr")
    add_element(props, "w:color", **{"w:val": "174B76"})
    add_element(props, "w:u", **{"w:val": "single"})
    add_element(run, "w:t").text = label
    paragraph._p.append(link)


def setup_document():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(PAGE_WIDTH)
    section.page_height = Inches(PAGE_HEIGHT)
    section.left_margin = section.right_margin = Inches(0.8)
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.header_distance = Inches(0.25)
    section.footer_distance = Inches(0.28)

    for name in ("Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Caption"):
        style = doc.styles[name]
        style.font.name = FONT
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:ascii"), FONT)
        style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"), FONT)
        for pborder in style.element.xpath("./w:pPr/w:pBdr"):
            pborder.getparent().remove(pborder)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(11)
    normal.paragraph_format.line_spacing = 1.13
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.widow_control = True
    title = doc.styles["Title"]
    title.font.size = Pt(24)
    title.font.bold = True
    title.paragraph_format.space_after = Pt(9)
    subtitle = doc.styles["Subtitle"]
    subtitle.font.size = Pt(12)
    subtitle.paragraph_format.space_after = Pt(6)
    for name, size in (("Heading 1", 14), ("Heading 2", 11.5)):
        style = doc.styles[name]
        style.font.size = Pt(size)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(13)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.keep_with_next = True
    doc.styles["Caption"].font.size = Pt(9)
    doc.styles["Caption"].font.italic = False
    doc.styles["Caption"].paragraph_format.space_after = Pt(9)
    doc.styles["Caption"].paragraph_format.line_spacing = 1.05

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.paragraph_format.space_after = Pt(0)
    footer.paragraph_format.line_spacing = 1.0
    field = add_element(footer._p, "w:fldSimple", **{"w:instr": "PAGE"})
    run = add_element(field, "w:r")
    props = add_element(run, "w:rPr")
    add_element(props, "w:rFonts", **{"w:ascii": FONT, "w:hAnsi": FONT})
    add_element(props, "w:sz", **{"w:val": 18})
    add_element(props, "w:szCs", **{"w:val": 18})
    add_element(run, "w:t").text = "1"
    return doc


def add_table(doc, block):
    headers, rows = block["headers"], block["rows"]
    widths = block.get("widths", [CONTENT_WIDTH / len(headers)] * len(headers))
    if len(widths) != len(headers) or abs(sum(widths) - CONTENT_WIDTH) > 0.02:
        raise ValueError("Table widths must match its columns and total 6.9 inches")
    if block.get("caption"):
        p = doc.add_paragraph(style="Caption")
        p.paragraph_format.keep_with_next = True
        add_text(p, block["caption"])
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    props = table._tbl.tblPr
    borders = add_element(props, "w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        add_element(borders, "w:" + edge, **{"w:val": "single", "w:sz": 4, "w:color": "D9D9D9"})
    margins = add_element(props, "w:tblCellMar")
    for edge, val in (("top", 90), ("bottom", 90), ("left", 100), ("right", 100)):
        add_element(margins, "w:" + edge, **{"w:w": val, "w:type": "dxa"})
    for col, width in zip(table.columns, widths):
        col.width = Inches(width)
    for index, values in enumerate([headers] + rows):
        row = table.rows[0] if index == 0 else table.add_row()
        trprops = row._tr.get_or_add_trPr()
        add_element(trprops, "w:cantSplit")
        if index == 0:
            add_element(trprops, "w:tblHeader")
        for column, (cell, value, width) in enumerate(zip(row.cells, values, widths)):
            cell.width = Inches(width)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            shading = "233F5B" if index == 0 else ("F3F5F7" if index % 2 == 0 else "FFFFFF")
            add_element(cell._tc.get_or_add_tcPr(), "w:shd", **{"w:fill": shading})
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.04
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if column == 0 else WD_ALIGN_PARAGRAPH.CENTER
            if column in block.get("left_columns", []):
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            add_text(p, value, bold=index == 0)
            for run in p.runs:
                run.font.size = Pt(block.get("font_size", 9.5))
                run.font.color.rgb = RGBColor.from_string("FFFFFF" if index == 0 else "000000")
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 0.3
    p.add_run().font.size = Pt(2)


def add_figure(doc, block, specdir):
    path = Path(block["path"])
    if not path.is_absolute():
        path = specdir / path
    with Image.open(path) as im:
        pxw, pxh = im.size
    width = min(float(block.get("width", CONTENT_WIDTH)), CONTENT_WIDTH)
    height = width * pxh / pxw
    if height > float(block.get("max_height", 7.8)):
        width *= float(block.get("max_height", 7.8)) / height
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    picture = p.add_run().add_picture(str(path), width=Inches(width))
    picture._inline.docPr.set("descr", block.get("alt", block.get("caption", path.stem)))
    p = doc.add_paragraph(style="Caption")
    add_text(p, block.get("caption", ""))


def build(spec, specdir, output):
    if spec.get("draft"):
        raise ValueError("Report specification is still a draft; complete and review the findings first")
    if re.search(r"\[\[[A-Z_]+\]\]", json.dumps(spec)):
        raise ValueError("Report specification contains unresolved placeholders")
    doc = setup_document()
    doc.core_properties.title = spec["title"]
    doc.core_properties.subject = "Balanced bipartition comparison of BURY and min-cutrank"
    doc.core_properties.author = "QuantumHamlets research"
    doc.core_properties.keywords = "BURY, cut rank, GF(2), graph partitioning, simulated annealing"
    doc.add_paragraph(spec["title"], "Title")
    if spec.get("subtitle"):
        doc.add_paragraph(spec["subtitle"], "Subtitle")
    if spec.get("date"):
        doc.add_paragraph(spec["date"])
    pending_page_break = False
    for block in spec["blocks"]:
        kind = block.get("type", "paragraph")
        before_paragraphs = len(doc.paragraphs)
        if kind == "paragraph":
            p = doc.add_paragraph()
            add_text(p, block["text"])
            if block.get("small"):
                for run in p.runs:
                    run.font.size = Pt(9)
            if block.get("keep_next"):
                p.paragraph_format.keep_with_next = True
        elif kind == "heading":
            if re.search(r"[^\w\s]", block["text"]):
                raise ValueError("Document headings use words, numbers and spaces only")
            doc.add_heading(block["text"], level=int(block.get("level", 1)))
        elif kind == "table":
            add_table(doc, block)
        elif kind == "figure":
            add_figure(doc, block, specdir)
        elif kind == "pagebreak":
            pending_page_break = True
            continue
        elif kind == "reference":
            p = doc.add_paragraph()
            if block.get("prefix"):
                add_text(p, block["prefix"] + " ")
            add_hyperlink(p, block["label"], block["url"])
            if block.get("suffix"):
                add_text(p, " " + block["suffix"])
            for run in p.runs:
                run.font.size = Pt(9)
        else:
            raise ValueError(f"Unknown report block type {kind}")
        if pending_page_break:
            doc.paragraphs[before_paragraphs].paragraph_format.page_break_before = True
            pending_page_break = False
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    with args.spec.open() as stream:
        spec = json.load(stream)
    print(build(spec, args.spec.resolve().parent, args.output.resolve()))


if __name__ == "__main__":
    main()
