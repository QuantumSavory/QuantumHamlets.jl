#!/usr/bin/env python3
"""Independent audit of saved min-cutrank comparison tasks and budget snapshots.

Read-only with respect to all experiment evidence. Only the requested fresh
audit JSON is written. Integer-bitset rank elimination uses least-significant
pivots and precomputed adjacency rows, independently of the runner's evaluator.
"""

from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import time


def read_table(path):
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def canonical_flags(labels):
    n = len(labels)
    if labels.count("1") > n // 2:
        return "".join("0" if bit == "1" else "1" for bit in labels)
    return labels


def rank_oracle(adjacency_bits, labels):
    """GF(2) row elimination with LSB pivots and sparse integer masks."""
    columns_mask = sum(1 << i for i, bit in enumerate(labels) if bit == "0")
    basis = [0] * len(labels)
    rank = 0
    for i, bit in enumerate(labels):
        if bit != "1":
            continue
        row = adjacency_bits[i] & columns_mask
        while row:
            pivot = (row & -row).bit_length() - 1
            if basis[pivot]:
                row ^= basis[pivot]
            else:
                basis[pivot] = row
                rank += 1
                break
    return rank


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--output-file", type=Path)
    parser.add_argument("--partial", action="store_true",
                        help="Audit currently finished task files, without requiring full coverage")
    args = parser.parse_args()
    started = time.perf_counter()
    run_dir = args.run_dir.resolve()
    root = Path(__file__).resolve().parent
    output = args.output_file or (run_dir / (
        "comparison_audit_partial.json" if args.partial else "comparison_audit.json"))
    if output.exists():
        raise SystemExit(f"Refusing to overwrite {output}")
    inputs = read_table(run_dir / "inputs.tsv")
    by_id = {row["id"]: row for row in inputs}
    baselines = read_table(run_dir / "baselines.tsv")
    baseline_map = {(row["id"], row["method"], int(row["seed"])): row for row in baselines}
    protocol = json.loads((run_dir / "protocol.json").read_text())
    counts = Counter()
    context = "protocol"

    def check(condition, category, detail=""):
        if not condition:
            raise AssertionError(f"{context}: {category}: {detail}")
        counts[category] += 1

    check(hashlib.sha256((run_dir / "inputs.tsv").read_bytes()).hexdigest()
          == protocol["manifest_sha256"], "input_manifest_hash")
    check(hashlib.sha256((run_dir / "baselines.tsv").read_bytes()).hexdigest()
          == protocol["baselines_sha256"], "baseline_hash")
    check(hashlib.sha256((root / "run_annealing.py").read_bytes()).hexdigest()
          == protocol["runner_sha256"], "runner_hash")
    upstream_sha = subprocess.check_output(
        ["git", "-C", str(root / "upstream"), "rev-parse", "HEAD"], text=True).strip()
    check(upstream_sha == protocol["upstream_commit"], "upstream_commit")
    upstream_validation_path = run_dir / protocol.get("upstream_validation_reference", "upstream_validation.json")
    upstream_validation = json.loads(upstream_validation_path.read_text())
    for name, digest in upstream_validation["source_sha256"].items():
        check(hashlib.sha256((root / "upstream" / "src" / "min-cutrank" / name).read_bytes()).hexdigest()
              == digest, "upstream_source_hash", name)

    adjacency_bits = {}
    edges_by_id = {}
    for entry in inputs:
        context = entry["id"]
        path = run_dir / "edges" / (entry["id"] + ".tsv")
        check(hashlib.sha256(path.read_bytes()).hexdigest() == entry["edge_sha256"], "edge_hash")
        edges = [(int(row["u"]), int(row["v"])) for row in read_table(path)]
        bits = [0] * int(entry["n"])
        for u, v in edges:
            bits[u] |= 1 << v
            bits[v] |= 1 << u
        adjacency_bits[entry["id"]] = bits
        edges_by_id[entry["id"]] = edges

    tasks = []
    task_hashes = {}
    for path in sorted((run_dir / "tasks").glob("*.json")):
        # The collector writes each completed record once. In partial mode wait
        # for its file to be at least two seconds old before observing it.
        if args.partial and time.time() - path.stat().st_mtime < 2:
            continue
        raw = path.read_bytes()
        task = json.loads(raw)
        tasks.append(task)
        task_hashes[path.name] = hashlib.sha256(raw).hexdigest()
    context = "coverage"
    expected = {(row["id"], method, seed) for row in inputs
                for method in protocol["methods"] for seed in protocol["annealing_seeds"]}
    actual = [(row["id"], row["method"], row["seed"]) for row in tasks]
    check(len(set(actual)) == len(actual), "no_duplicate_task_keys")
    check(set(actual) <= expected, "no_unplanned_task_keys")
    if not args.partial:
        check(set(actual) == expected, "complete_task_coverage")

    statuses = Counter()
    final_above_incumbent = 0
    final_above_initial = 0
    native_finals_after_cap = []
    maximum_native_final_seconds = 0.0
    snapshot_available = Counter()
    max_wall_overrun = 0.0
    checked_memberships = 0
    rank_cache = {}

    def validate_candidate(task, candidate):
        nonlocal checked_memberships
        if candidate is None:
            return
        labels = candidate["labels"]
        n = task["n"]
        check(len(labels) == n and set(labels) <= {"0", "1"}, "candidate_bits")
        check(labels.count("1") == n // 2, "exact_floor_rows")
        cache_key = (task["id"], labels)
        if cache_key not in rank_cache:
            rank_cache[cache_key] = rank_oracle(adjacency_bits[task["id"]], labels)
        check(rank_cache[cache_key] == candidate["rank"], "independent_candidate_rank")
        check(candidate["seconds"] >= task["initializer_seconds"], "initializer_time_charged")
        check(0 <= candidate["python_cpu_seconds"] <= task["python_cpu_seconds"] + 1e-6,
              "candidate_cpu_time_domain")
        check(candidate["seconds"] <= task["solve_seconds"] + 1e-6, "candidate_before_finish")
        checked_memberships += 1

    for task in tasks:
        context = f"{task['id']}/{task['method']}/{task['seed']}"
        status = task["status"]
        statuses[status] += 1
        check(status in ("completed", "time_limit", "error", "worker_failure"), "known_status")
        if status == "worker_failure":
            check(bool(task["error"]), "failure_explanation")
            continue
        entry = by_id[task["id"]]
        check(task["n"] == int(entry["n"]) and task["m"] == int(entry["m"]), "task_graph_shape")
        check(task["solve_seconds"] >= task["initializer_seconds"] >= 0, "elapsed_time_domain")
        check(task["peak_process_rss_bytes"] > 0, "rss_domain")
        check(0 <= task["completed_sweeps"] <= protocol["sweeps"], "sweep_count_domain")
        check(task["completed_sweeps"] == len(task["sweep_trace"]), "sweep_trace_count")
        if status == "completed":
            check(task["completed_sweeps"] == protocol["sweeps"], "native_completed_all_sweeps")
            check(task["final"] is not None and task["error"] is None, "native_final_present")
        else:
            check(task["final"] is None, "incomplete_has_no_native_final")
        if status == "time_limit":
            check(task["solve_seconds"] >= protocol["per_run_wall_limit_seconds"] - 0.01,
                  "timeout_not_early")
        max_wall_overrun = max(max_wall_overrun,
                              task["solve_seconds"] - protocol["per_run_wall_limit_seconds"])

        if task["method"] == "random_sa":
            flags = [True] * (task["n"] // 2) + [False] * (task["n"] - task["n"] // 2)
            random.Random(100000 + task["seed"]).shuffle(flags)
            expected_initial = "".join("1" if flag else "0" for flag in flags)
            check(task["initializer_seconds"] == 0, "random_initializer_charge")
        else:
            method, seed = ("bury", -1) if task["method"] == "bury_sa" else ("sqrt_bury", task["seed"])
            base = baseline_map[(task["id"], method, seed)]
            expected_initial = canonical_flags(base["labels"])
            check(task["initializer_seconds"] == float(base["solve_seconds"]), "hybrid_initializer_charge")
            check(task["initial_rank"] == int(base["rank"]), "hybrid_initial_rank")
        check(task["initial_labels"] == expected_initial, "initial_membership_and_seed")
        check(rank_oracle(adjacency_bits[task["id"]], expected_initial) == task["initial_rank"],
              "independent_initial_rank")
        events = task["incumbent_events"]
        for previous, current in zip(events, events[1:]):
            check(previous["seconds"] <= current["seconds"], "event_times_nondecreasing")
            check(previous["rank"] > current["rank"], "incumbent_ranks_strictly_decreasing")
        if events:
            check(events[0]["labels"] == expected_initial
                  and events[0]["rank"] == task["initial_rank"], "initial_event")
        for candidate in events:
            validate_candidate(task, candidate)
        validate_candidate(task, task["final"])
        if task["final"] is not None:
            check(task["final"]["rank"] >= events[-1]["rank"], "incumbent_no_worse_than_final")
            final_above_incumbent += task["final"]["rank"] > events[-1]["rank"]
            final_above_initial += task["final"]["rank"] > task["initial_rank"]
            maximum_native_final_seconds = max(maximum_native_final_seconds, task["final"]["seconds"])
            if task["final"]["seconds"] > protocol["per_run_wall_limit_seconds"]:
                native_finals_after_cap.append(dict(id=task["id"], method=task["method"],
                                                    seed=task["seed"], seconds=task["final"]["seconds"]))
        for index, sweep in enumerate(task["sweep_trace"]):
            check(sweep["sweep"] == index + 1, "sweep_sequence")
            check(sweep["seconds"] <= task["solve_seconds"], "sweep_before_finish")
            previous_events = [event for event in events if event["seconds"] <= sweep["seconds"]]
            check(previous_events and previous_events[-1]["rank"] == sweep["incumbent_rank"],
                  "sweep_incumbent_consistency")
            check(sweep["rank"] >= sweep["incumbent_rank"], "sweep_rank_bound")
        check([row["budget"] for row in task["budget_snapshots"]] == protocol["budgets_seconds"],
              "budget_coverage")
        for snapshot in task["budget_snapshots"]:
            budget = snapshot["budget"]
            available = [event for event in events if event["seconds"] <= budget]
            check(snapshot["candidate"] == (available[-1] if available else None),
                  "snapshot_is_latest_eligible_incumbent")
            if snapshot["candidate"] is not None:
                check(snapshot["candidate"]["seconds"] <= budget, "strict_budget_availability")
                snapshot_available[str(budget)] += 1

    # Re-run stock upstream (without observer or deadline) on a fixed small
    # subset. This verifies the main adapter's membership outcomes and seed use.
    sys.path.insert(0, str(root / "upstream" / "src" / "min-cutrank"))
    from graph_partition import GraphPartition
    from cut_rank_annealing import cut_rank_annealing_row_formula
    import numpy as np
    replays = []
    for method in protocol["methods"]:
        candidates = [task for task in tasks if task["method"] == method
                      and task["status"] == "completed" and task["n"] <= 80]
        for task in candidates[:6]:
            context = f"stock replay {task['id']}/{method}/{task['seed']}"
            adjacency = [[0] * task["n"] for _ in range(task["n"])]
            for u, v in edges_by_id[task["id"]]:
                adjacency[u][v] = adjacency[v][u] = 1
            partition = GraphPartition(adjacency, [bit == "1" for bit in task["initial_labels"]])
            random.seed(task["seed"])
            cut_rank_annealing_row_formula(partition, np.linspace(1.0, 0.1, protocol["sweeps"]), False)
            labels = "".join("1" if flag else "0" for flag in partition.row_flag)
            check(labels == task["final"]["labels"], "stock_replay_final_membership")
            check(partition.cut_rank == task["final"]["rank"], "stock_replay_final_rank")
            replays.append(dict(id=task["id"], method=method, seed=task["seed"]))

    result = dict(
        status="passed", scope="partial" if args.partial else "complete",
        assertions=sum(counts.values()), counts=dict(sorted(counts.items())),
        planned_tasks=len(expected), audited_tasks=len(tasks), statuses=dict(statuses),
        checked_memberships=checked_memberships, unique_scored_memberships=len(rank_cache),
        available_budget_candidates=dict(snapshot_available),
        native_final_above_incumbent=final_above_incumbent,
        native_final_above_initializer=final_above_initial,
        native_finals_after_cap_count=len(native_finals_after_cap),
        native_finals_after_cap=native_finals_after_cap,
        maximum_native_final_seconds=maximum_native_final_seconds,
        maximum_wall_cap_overrun_seconds=max_wall_overrun,
        stock_upstream_replays=replays,
        tasks_sha256=task_hashes,
        protocol_sha256=hashlib.sha256((run_dir / "protocol.json").read_bytes()).hexdigest(),
        seconds=time.perf_counter() - started,
        limitations="Reruns stock upstream only for the listed small subset; verifies every saved rank and membership, but does not reproduce wall-clock timings or prove optimality.",
    )
    output.write_text(json.dumps(result, indent=2) + "\n")
    summary = {key: value for key, value in result.items()
               if key not in ("counts", "tasks_sha256", "stock_upstream_replays")}
    summary["stock_upstream_replays"] = len(replays)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
