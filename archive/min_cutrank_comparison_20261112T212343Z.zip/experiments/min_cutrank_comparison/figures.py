#!/usr/bin/env python3
"""Render scientific comparison figures from frozen tables and event traces.

This module never runs partitioners and refuses to overwrite rendered outputs.
Use an existing Python runtime with matplotlib and NumPy.  Revisions can
be rendered to a new --output-dir while retaining all earlier artifacts.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np


COLORS = {"bury": "#0072B2", "sqrt_bury": "#009E73", "random_sa": "#D55E00",
          "bury_sa": "#8E5EA2", "sqrt_sa": "#28A4B8"}
LABELS = {"bury": "BURY", "sqrt_bury": "sqrt BURY", "random_sa": "Random + SA",
          "bury_sa": "BURY + SA", "sqrt_sa": "sqrt BURY + SA"}
STANDALONE = ("bury", "sqrt_bury", "random_sa")
HYBRID = ("random_sa", "bury_sa", "sqrt_sa")
ALL_METHODS = ("bury", "sqrt_bury", "random_sa", "bury_sa", "sqrt_sa")
COLLECTIONS = {"graphml_initial": "Initial", "graphml_reduced": "Reduced", "graphml_evolution": "Evolution"}
SEED_MARKERS = ("o", "^", "s")


def table(path):
    with Path(path).open() as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def number(value):
    return float(value) if value != "" else math.nan


def value_label(value):
    return str(int(round(value))) if abs(value - round(value)) < 1e-8 else f"{value:.1f}"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10.5,
        "axes.titlesize": 12, "axes.labelsize": 10.5,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": "#9A9A9A", "axes.linewidth": 0.65,
        "xtick.color": "#454545", "ytick.color": "#454545",
        "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
        "figure.facecolor": "white", "axes.facecolor": "white",
        "savefig.facecolor": "white", "pdf.fonttype": 42,
        "ps.fonttype": 42, "svg.fonttype": "none",
    })


class Plotter:
    def __init__(self, run, output):
        self.run, self.output = Path(run), Path(output)
        self.inputs = table(self.run / "inputs.tsv")
        self.by_id = {row["id"]: row for row in self.inputs}
        self.summary = table(self.run / "summary.tsv")
        self.results = table(self.run / "results.tsv")
        self.baselines = table(self.run / "baselines.tsv")
        self.lookup = {(r["id"], r["method"], r["view"], self.budget_key(r["budget_seconds"])): r
                       for r in self.summary}
        self.tasks = [json.loads(path.read_text()) for path in sorted((self.run / "tasks").glob("*.json"))]
        self.task_lookup = {(r["id"], r["method"], int(r["seed"])): r for r in self.tasks}
        self.figures, self.displayed, self.curves = [], [], []
        self.output.mkdir(parents=True, exist_ok=True)
        if any(self.output.iterdir()):
            raise FileExistsError(f"render to a fresh directory: {self.output}")

    @staticmethod
    def budget_key(value):
        return "" if value == "" else float(value)

    def get(self, graph_id, method, view="native", budget=""):
        return self.lookup[graph_id, method, view, self.budget_key(budget)]

    def select(self, collection=None, family=None):
        return sorted([r for r in self.inputs if (collection is None or r["collection"] == collection)
                       and (family is None or r["family"] == family)],
                      key=lambda r: (int(r["parameter"] or 0), r["id"]))

    def save(self, fig, stem, caption, methods, graph_ids):
        files = []
        for extension in ("png", "svg", "pdf"):
            path = self.output / f"{stem}.{extension}"
            if path.exists():
                raise FileExistsError(path)
            fig.savefig(path, dpi=180 if extension == "png" else None, bbox_inches="tight", pad_inches=0.12)
            files.append(dict(path=path.name, sha256=digest(path), bytes=path.stat().st_size))
        self.figures.append(dict(stem=stem, caption=caption, methods=list(methods), graph_ids=list(graph_ids), files=files))
        plt.close(fig)

    @staticmethod
    def legend(fig, methods, y=0.94):
        fig.legend(handles=[Patch(facecolor=COLORS[m], label=LABELS[m]) for m in methods],
                   loc="upper center", bbox_to_anchor=(0.5, y), ncol=len(methods),
                   frameon=False, fontsize=10.8, handlelength=1.2, columnspacing=2.1)

    @staticmethod
    def axes_style(ax, horizontal=False):
        ax.set_axisbelow(True)
        ax.grid(axis="x" if horizontal else "y", color="#E5E5E5", linewidth=0.6)
        ax.tick_params(axis="both", length=3)

    def record(self, stem, panel, graph_id, method, view, budget, row, aggregation="run median"):
        self.displayed.append(dict(figure=stem, panel=panel, id=graph_id, method=method,
            view=view, budget_seconds=budget, aggregation=aggregation, median=row["rank_median"],
            minimum=row["rank_min"], maximum=row["rank_max"], valid=row["valid"], total=row["total"]))

    def bars(self, ax, stem, panel, graphs, methods, view="native", budget="", tick_labels=None,
             counts_methods=(), horizontal=False, label_font=8.5):
        width = 0.78 / len(methods)
        positions = np.arange(len(graphs), dtype=float)
        rows = [self.get(g["id"], m, view, budget) for g in graphs for m in methods]
        high = max([number(r["rank_max"]) for r in rows if int(r["valid"])] + [1])
        high = max(high, 1)
        pad = high * 0.035
        for mi, method in enumerate(methods):
            xs = positions + (mi - (len(methods) - 1) / 2) * width
            for gi, (g, x) in enumerate(zip(graphs, xs)):
                row = self.get(g["id"], method, view, budget)
                self.record(stem, panel, g["id"], method, view, budget, row)
                valid, total = int(row["valid"]), int(row["total"])
                if not valid:
                    if horizontal:
                        ax.text(pad, x, f"unavailable ({valid}/{total})", color=COLORS[method],
                                fontsize=label_font, ha="left", va="center")
                    else:
                        ax.text(x, pad, f"NA\n{valid}/{total}", color=COLORS[method], fontsize=label_font,
                                ha="center", va="bottom")
                    continue
                median, low, maximum = (number(row[f"rank_{stat}"]) for stat in ("median", "min", "max"))
                hatch = "///" if valid < total else None
                errors = np.array([[median - low], [maximum - median]])
                if horizontal:
                    ax.barh(x, median, height=width * .91, color=COLORS[method], alpha=.92,
                            hatch=hatch, edgecolor="white", linewidth=.25)
                    ax.errorbar(median, x, xerr=errors, fmt="none", ecolor="#333333", elinewidth=.8, capsize=2)
                else:
                    ax.bar(x, median, width=width * .91, color=COLORS[method], alpha=.92,
                           hatch=hatch, edgecolor="white", linewidth=.25)
                    ax.errorbar(x, median, yerr=errors, fmt="none", ecolor="#333333", elinewidth=.8, capsize=2)
                text = value_label(median)
                if method in counts_methods or valid < total:
                    text += f" ({valid}/{total})" if horizontal else f"\n{valid}/{total}"
                if horizontal:
                    ax.text(maximum + pad, x, text, fontsize=label_font, ha="left", va="center", color="#272727")
                else:
                    ax.text(x, maximum + pad, text, fontsize=label_font, ha="center", va="bottom",
                            color="#272727", linespacing=1.05)
        labels = tick_labels or [f"{g['parameter']}\n(n={g['n']})" for g in graphs]
        self.axes_style(ax, horizontal)
        if horizontal:
            ax.set_yticks(positions, labels)
            ax.invert_yaxis()
            ax.set_xlim(0, high * 1.35 + .5)
            ax.set_xlabel("GF(2) cut rank  ↓")
        else:
            ax.set_xticks(positions, labels)
            ax.set_ylim(0, high * 1.23 + .6)
            ax.set_xlim(-.6, len(graphs) - .4)
            ax.set_ylabel("GF(2) cut rank  ↓")

    def circuit_panels(self, hybrid=False):
        stem = "hybrid_rank_30s" if hybrid else "circuit_rank_native"
        methods = HYBRID if hybrid else STANDALONE
        view, budget = ("incumbent", 30.0) if hybrid else ("native", "")
        families = (("gf_multiplier", "GF multipliers", "Field exponent m"),
                    ("toffoli", "Toffoli", "Circuit parameter"),
                    ("barenco_toffoli", "Barenco Toffoli", "Circuit parameter"))
        fig, axes = plt.subplots(2, 3, figsize=(14.8, 8.6))
        fig.subplots_adjust(left=.06, right=.985, bottom=.17, top=.84, hspace=.53, wspace=.26)
        fig.suptitle("BURY initialization and annealing at 30 seconds" if hybrid else
                     "Circuit families under exact bipartition balance", x=.5, y=.985, fontsize=18, weight="bold")
        self.legend(fig, methods, .946)
        all_ids = []
        for ri, collection in enumerate(("graphml_initial", "graphml_reduced")):
            for ci, (family, title, xlabel) in enumerate(families):
                graphs = self.select(collection, family)
                panel = f"{COLLECTIONS[collection]} {title}"
                ax = axes[ri, ci]
                self.bars(ax, stem, panel, graphs, methods, view, budget)
                ax.set_title(panel, loc="left", weight="bold", pad=10)
                ax.set_xlabel(xlabel)
                all_ids.extend(g["id"] for g in graphs)
        caption = (
            "Best rank observed by 30 s, including initializer and setup. Bars: median of 10 runs; whiskers: observed min–max. "
            "Counts appear if fewer than 10 candidates are available. Search uses at most 10 sweeps; no restarts."
            if hybrid else
            "Native outputs: one ordinary BURY result and 10 runs for sqrt BURY and random-start annealing. "
            "Bars: median; whiskers: observed min–max. Annealing completes 10/10 unless a smaller count is shown; NA means no completed 10-sweep run within 30 s."
        )
        fig.text(.06, .025, self.wrap(caption, 160), fontsize=9.4, va="bottom", color="#454545")
        self.save(fig, stem, caption, methods, all_ids)

        # A single collection per report panel keeps labels readable at 6.9 in.
        for collection in ("graphml_initial", "graphml_reduced"):
            report_stem = "report_" + stem + "_" + COLLECTIONS[collection].lower()
            report, report_axes = plt.subplots(1, 3, figsize=(10.2, 4.7))
            report.subplots_adjust(left=.10, right=.985, bottom=.17, top=.72, wspace=.65)
            report.suptitle(COLLECTIONS[collection] + (" circuits at 30 seconds" if hybrid else " circuit native outputs"),
                            y=.99, fontsize=17, weight="bold")
            self.legend(report, methods, .925)
            report_ids = []
            for ax, (family, title, xlabel) in zip(report_axes, families):
                graphs = self.select(collection, family)
                self.bars(ax, report_stem, title, graphs, methods, view, budget,
                          counts_methods=(), horizontal=True, label_font=10.8)
                ax.set_title(title, loc="left", weight="bold", fontsize=12.6, pad=11)
                ax.set_xlabel("GF(2) cut rank", fontsize=12)
                ax.set_ylabel("")
                ax.tick_params(labelsize=11.5)
                report_ids.extend(g["id"] for g in graphs)
            report.text(.07, .03, "Median bars and observed min–max whiskers. " +
                        ("Best candidate by 30 s; 10 runs per method." if hybrid else
                         "SA completed 10/10 unless a smaller count is shown."), fontsize=10.5, color="#454545")
            self.save(report, report_stem, caption, methods, report_ids)

    @staticmethod
    def wrap(text, width):
        import textwrap
        return "\n".join(textwrap.wrap(text, width))

    def evolution(self):
        stem = "evolution_rank"
        graphs = self.select("graphml_evolution", "evolution")
        fig, axes = plt.subplots(1, 3, figsize=(17.6, 5.8))
        fig.subplots_adjust(left=.045, right=.99, bottom=.19, top=.79, wspace=.25)
        fig.suptitle("Evolution graphs under exact bipartition balance", y=.985, fontsize=18, weight="bold")
        self.legend(fig, ALL_METHODS, .945)
        for ax, panel, methods, view, budget in (
            (axes[0], "Native standalone outputs", STANDALONE, "native", ""),
            (axes[1], "Standalone incumbents at 30 s", STANDALONE, "incumbent", 30.0),
            (axes[2], "Annealing incumbents at 30 s", HYBRID, "incumbent", 30.0),
        ):
            self.bars(ax, stem, panel, graphs, methods, view, budget)
            ax.set_title(panel, loc="left", weight="bold")
            ax.set_xlabel("Evolution stage")
        caption = ("Bars: median; whiskers: observed min–max. BURY has one result; other methods have 10 runs. "
            "Native SA needs all 10 sweeps within 30 s; it completes 10/10 unless a smaller count is shown. Incumbents retain the best completed candidate, "
            "including initialization, even when a run reaches its time limit.")
        fig.text(.045, .035, self.wrap(caption, 190), fontsize=9.4, va="bottom", color="#454545")
        self.save(fig, stem, caption, ALL_METHODS, [g["id"] for g in graphs])
        for name, title, methods, view, budget in (
            ("native", "Evolution native outputs", STANDALONE, "native", ""),
            ("standalone_30s", "Evolution standalone incumbents at 30 seconds", STANDALONE, "incumbent", 30.0),
            ("hybrid_30s", "Evolution annealing incumbents at 30 seconds", HYBRID, "incumbent", 30.0),
        ):
            report, ax = plt.subplots(figsize=(7.4, 4.6))
            report.subplots_adjust(left=.10, right=.985, bottom=.19, top=.73)
            report.suptitle(title, y=.99, fontsize=15.5, weight="bold")
            self.legend(report, methods, .92)
            self.bars(ax, "report_evolution_" + name, title, graphs, methods, view, budget,
                      counts_methods=(), label_font=11)
            ax.tick_params(labelsize=11.5)
            ax.set_xlabel("Evolution stage", fontsize=12)
            ax.set_ylabel("GF(2) cut rank", fontsize=12)
            self.save(report, "report_evolution_" + name, caption, methods, [g["id"] for g in graphs])

    def remaining(self):
        stem = "remaining_circuits_native"
        fig, axes = plt.subplots(1, 2, figsize=(14.5, 10.1))
        fig.subplots_adjust(left=.14, right=.985, bottom=.105, top=.86, wspace=.37)
        fig.suptitle("All remaining circuit families", y=.985, fontsize=18, weight="bold")
        self.legend(fig, STANDALONE, .947)
        all_ids = []
        for ax, collection in zip(axes, ("graphml_initial", "graphml_reduced")):
            graphs = [g for g in self.select(collection) if g["family"] not in ("gf_multiplier", "toffoli", "barenco_toffoli")]
            graphs.sort(key=lambda g: g["label"])
            labels = [g["label"].replace("_", " ") + f"\n(n={g['n']})" for g in graphs]
            self.bars(ax, stem, COLLECTIONS[collection], graphs, STANDALONE,
                      tick_labels=labels, counts_methods=("random_sa",), horizontal=True)
            ax.set_title(COLLECTIONS[collection], loc="left", weight="bold")
            all_ids.extend(g["id"] for g in graphs)
        caption = ("All nine other graphs in each collection are included. Native-output medians with observed min–max whiskers. "
            "Ordinary BURY: one run; sqrt BURY: 10 runs. Parentheses show random-SA completed/10 within the 30 s limit; "
            "partial samples are hatched and unavailable outputs are labeled.")
        fig.text(.045, .025, self.wrap(caption, 155), fontsize=9.4, va="bottom", color="#454545")
        self.save(fig, stem, caption, STANDALONE, all_ids)
        for collection in ("graphml_initial", "graphml_reduced"):
            report_stem = "report_remaining_" + COLLECTIONS[collection].lower()
            graphs = [g for g in self.select(collection) if g["family"] not in ("gf_multiplier", "toffoli", "barenco_toffoli")]
            graphs.sort(key=lambda g: g["label"])
            report, ax = plt.subplots(figsize=(7.4, 8.2))
            report.subplots_adjust(left=.23, right=.98, bottom=.075, top=.86)
            report.suptitle(COLLECTIONS[collection] + " remaining circuits", y=.99, fontsize=16, weight="bold")
            self.legend(report, STANDALONE, .945)
            self.bars(ax, report_stem, COLLECTIONS[collection], graphs, STANDALONE,
                      tick_labels=[g["label"].replace("_", " ") + f"\n(n={g['n']})" for g in graphs],
                      counts_methods=("random_sa",), horizontal=True, label_font=10.3)
            ax.tick_params(labelsize=11)
            ax.set_xlabel("GF(2) cut rank", fontsize=12)
            self.save(report, report_stem, caption, STANDALONE, [g["id"] for g in graphs])

    def synthetic(self):
        stem = "synthetic_rank_native"
        fig, axes = plt.subplots(1, 3, figsize=(15.8, 5.9))
        fig.subplots_adjust(left=.055, right=.985, bottom=.215, top=.77, wspace=.27)
        fig.suptitle("Grids and sparse random graphs", y=.985, fontsize=18, weight="bold")
        self.legend(fig, STANDALONE, .946)
        grid = self.select("synthetic", "grid")
        self.bars(axes[0], stem, "Square grids", grid, STANDALONE,
                  tick_labels=[g["label"] for g in grid])
        axes[0].set_title("Square grids", loc="left", weight="bold")
        axes[0].set_xlabel("Grid dimensions")
        all_ids = [g["id"] for g in grid]
        width = .24
        for ax, family, degree in zip(axes[1:], ("er_c2", "er_c5"), (2, 5)):
            graphs = self.select("synthetic", family)
            high = max(number(self.get(g["id"], m)["rank_median"]) for g in graphs for m in STANDALONE)
            high = max(high, 1)
            for mi, method in enumerate(STANDALONE):
                for ni, n in enumerate((40, 80, 120)):
                    selected = sorted([g for g in graphs if int(g["n"]) == n], key=lambda g: g["id"])
                    rows = [self.get(g["id"], method) for g in selected]
                    if any(int(r["valid"]) != int(r["total"]) for r in rows):
                        raise ValueError("Synthetic graph aggregation requires complete native results; use per-graph panels if incomplete")
                    medians = np.array([number(r["rank_median"]) for r in rows])
                    center, low, upper = np.median(medians), medians.min(), medians.max()
                    x = ni + (mi - 1) * width
                    ax.bar(x, center, width=width*.86, color=COLORS[method], alpha=.85, edgecolor="white", linewidth=.3)
                    ax.errorbar(x, center, yerr=[[center-low], [upper-center]], fmt="none", color="#333333", capsize=2, elinewidth=.8)
                    for si, (g, row, median) in enumerate(zip(selected, rows, medians)):
                        ax.scatter(x + (si-1)*width*.18, median, marker=SEED_MARKERS[si], s=24,
                                   facecolor="white", edgecolor=COLORS[method], linewidth=1.05, zorder=4)
                        self.record(stem, f"ER c={degree}, n={n}", g["id"], method, "native", "", row,
                                    "graphwise run median; bar is median over three graphs")
                    ax.text(x, upper + high*.04, value_label(center), fontsize=8.5, ha="center", va="bottom")
            self.axes_style(ax)
            ax.set_ylim(0, high*1.23+.6)
            ax.set_xlim(-.6, 2.6)
            ax.set_xticks(range(3), ("40", "80", "120"))
            ax.set_xlabel("Vertices n")
            ax.set_ylabel("GF(2) cut rank  ↓")
            ax.set_title(f"Erdős–Rényi p={degree}/n", loc="left", weight="bold")
            all_ids.extend(g["id"] for g in graphs)
        fig.legend(handles=[Line2D([0], [0], marker=marker, color="none", markerfacecolor="white",
                     markeredgecolor="#444444", label=f"Graph seed {seed}", markersize=5)
                    for marker, seed in zip(SEED_MARKERS, (1000, 1001, 1002))],
                   loc="upper center", bbox_to_anchor=(.67, .881), ncol=3, frameon=False, fontsize=9.2,
                   handletextpad=.4, columnspacing=1.1)
        caption = ("Native outputs. Grids: run median and observed run min–max. Random graphs: bar = median of three graphwise run medians; "
            "markers show every graph seed and whiskers span those three medians. Each stochastic method has 10 runs per graph. "
            "Random graphs are not conditioned on connectivity; zero ranks are retained.")
        fig.text(.055, .035, self.wrap(caption, 170), fontsize=9.4, va="bottom", color="#454545")
        self.save(fig, stem, caption, STANDALONE, all_ids)
        for family, title in (("grid", "Square grids"), ("er_c2", "Sparse random graphs with p=2/n"),
                              ("er_c5", "Sparse random graphs with p=5/n")):
            report_stem = "report_synthetic_" + family
            graphs = self.select("synthetic", family)
            report, ax = plt.subplots(figsize=(7.4, 4.8))
            report.subplots_adjust(left=.105, right=.985, bottom=.16, top=.72)
            report.suptitle(title, y=.99, fontsize=16, weight="bold")
            self.legend(report, STANDALONE, .92)
            if family == "grid":
                self.bars(ax, report_stem, title, graphs, STANDALONE,
                          tick_labels=[g["label"] for g in graphs], label_font=11)
                ax.set_xlabel("Grid dimensions", fontsize=12)
            else:
                high = max(number(self.get(g["id"], m)["rank_median"]) for g in graphs for m in STANDALONE)
                high = max(high, 1)
                for mi, method in enumerate(STANDALONE):
                    for ni, n in enumerate((40, 80, 120)):
                        selected = sorted([g for g in graphs if int(g["n"]) == n], key=lambda g: g["id"])
                        rows = [self.get(g["id"], method) for g in selected]
                        medians = np.array([number(r["rank_median"]) for r in rows])
                        center, low, upper = np.median(medians), medians.min(), medians.max()
                        x = ni + (mi - 1) * width
                        ax.bar(x, center, width=width*.86, color=COLORS[method], alpha=.85, edgecolor="white", linewidth=.3)
                        ax.errorbar(x, center, yerr=[[center-low], [upper-center]], fmt="none", color="#333333", capsize=2, elinewidth=.8)
                        for si, (g, row, median) in enumerate(zip(selected, rows, medians)):
                            ax.scatter(x + (si-1)*width*.18, median, marker=SEED_MARKERS[si], s=35,
                                       facecolor="white", edgecolor=COLORS[method], linewidth=1.1, zorder=4)
                            self.record(report_stem, f"n={n}", g["id"], method, "native", "", row,
                                        "graphwise run median; bar is median over three graphs")
                        ax.text(x, upper + high*.04, value_label(center), fontsize=11, ha="center", va="bottom")
                self.axes_style(ax)
                ax.set_ylim(0, high*1.23+.6); ax.set_xlim(-.6, 2.6)
                ax.set_xticks(range(3), ("40", "80", "120"))
                ax.set_xlabel("Vertices n", fontsize=12)
                report.legend(handles=[Line2D([0], [0], marker=marker, color="none", markerfacecolor="white",
                    markeredgecolor="#444444", label=f"Graph seed {seed}", markersize=5)
                    for marker, seed in zip(SEED_MARKERS, (1000, 1001, 1002))], loc="upper center",
                    bbox_to_anchor=(.5, .835), ncol=3, frameon=False, fontsize=10)
            ax.set_ylabel("GF(2) cut rank", fontsize=12)
            ax.tick_params(labelsize=11.5)
            self.save(report, report_stem, caption, STANDALONE, [g["id"] for g in graphs])

    def histories(self, graph_id, method):
        if method in ("bury", "sqrt_bury"):
            return [[dict(seconds=float(row["solve_seconds"]), rank=int(row["rank"]))]
                    for row in self.baselines if row["id"] == graph_id and row["method"] == method]
        return [self.task_lookup[graph_id, method, seed].get("incumbent_events", []) for seed in range(10)]

    def quality_time(self):
        stem = "quality_vs_time"
        groups = [
            ("Initial GF multiplier m=6", ["graphml_initial__gf2^6_mult"]),
            ("Reduced GF multiplier m=6", ["graphml_reduced__gf2^6_mult"]),
            ("Evolution stage 5", ["graphml_evolution__k5"]),
            ("10 × 10 grid", ["synthetic__grid_10"]),
            ("ER n=120, p=2/n", [f"synthetic__er_n120_c2_s{s}" for s in (1000, 1001, 1002)]),
            ("ER n=120, p=5/n", [f"synthetic__er_n120_c5_s{s}" for s in (1000, 1001, 1002)]),
        ]
        fig, axes = plt.subplots(2, 3, figsize=(15.2, 8.9))
        fig.subplots_adjust(left=.06, right=.985, bottom=.14, top=.84, hspace=.39, wspace=.25)
        fig.suptitle("Best observed cut rank as time becomes available", y=.985, fontsize=18, weight="bold")
        fig.legend(handles=[Line2D([0], [0], color=COLORS[m], linewidth=2,
                         linestyle="--" if m in ("bury", "sqrt_bury") else "-", label=LABELS[m]) for m in ALL_METHODS],
                   loc="upper center", bbox_to_anchor=(.5, .945), ncol=5, frameon=False, fontsize=10.8)
        for ax, (title, graph_ids) in zip(axes.flat, groups):
            histories = {m: {g: self.histories(g, m) for g in graph_ids} for m in ALL_METHODS}
            event_times = [event["seconds"] for h_by_g in histories.values() for hs in h_by_g.values() for h in hs for event in h]
            xs = np.unique(np.array([*np.geomspace(1e-5, 30, 180), *[x for x in event_times if 1e-5 <= x <= 30], 30]))
            for method in ALL_METHODS:
                medians, lowers, uppers, coverages = [], [], [], []
                expected = (1 if method == "bury" else 10) * len(graph_ids)
                for x in xs:
                    by_graph, all_values = [], []
                    available = 0
                    for graph_id in graph_ids:
                        values = []
                        for history in histories[method][graph_id]:
                            reached = [event for event in history if event["seconds"] <= x]
                            if reached:
                                values.append(reached[-1]["rank"])
                        available += len(values)
                        if len(values) == (1 if method == "bury" else 10):
                            by_graph.append(statistics.median(values))
                            all_values.extend(values)
                    if available == expected:
                        if len(graph_ids) == 1:
                            center, low, high = statistics.median(all_values), min(all_values), max(all_values)
                        else:
                            center, low, high = statistics.median(by_graph), min(by_graph), max(by_graph)
                    else:
                        center = low = high = math.nan
                    medians.append(center); lowers.append(low); uppers.append(high); coverages.append(available)
                    self.curves.append(dict(figure=stem, panel=title, method=method, seconds=x,
                        median="" if math.isnan(center) else center, minimum="" if math.isnan(low) else low,
                        maximum="" if math.isnan(high) else high, available=available, required=expected,
                        aggregation="run median" if len(graph_ids) == 1 else "median of graphwise run medians"))
                ax.step(xs, medians, where="post", color=COLORS[method], linewidth=1.75,
                        linestyle="--" if method in ("bury", "sqrt_bury") else "-",
                        zorder=4 if method in ("bury", "sqrt_bury") else 3)
                ax.fill_between(xs, lowers, uppers, step="post", color=COLORS[method], alpha=.085, linewidth=0)
            self.axes_style(ax)
            ax.set_xscale("log")
            ax.set_xlim(1e-5, 30)
            ax.set_ylim(bottom=0)
            ax.set_xticks([1e-5, 1e-3, .1, 30], ["10 μs", "1 ms", "0.1 s", "30 s"])
            ax.set_xlabel("Cumulative solve time")
            ax.set_ylabel("GF(2) cut rank  ↓")
            subtitle = f"n={self.by_id[graph_ids[0]]['n']}" if len(graph_ids) == 1 else "All three graph seeds"
            ax.set_title(title + "\n" + subtitle, loc="left", weight="bold", fontsize=11.5)
        caption = ("Curves begin only when every required run has a candidate. Single graphs: run median with observed min–max shading. "
            "ER: median of three graphwise run medians; shading spans those three medians. Baselines use their original solve times. "
            "Annealing includes setup and BURY initialization, stops after 10 sweeps or 30 s, and does not restart. "
            "A finished run's incumbent is carried forward without further search. Wall times were measured with two Python workers.")
        fig.text(.06, .025, self.wrap(caption, 163), fontsize=9.2, va="bottom", color="#454545")
        self.save(fig, stem, caption, ALL_METHODS, [g for _, gs in groups for g in gs])
        for group_name, selected_groups in (("circuits", groups[:3]), ("synthetic", groups[3:])):
            report_stem = "report_quality_vs_time_" + group_name
            report, report_axes = plt.subplots(1, 3, figsize=(10.2, 4.7))
            report.subplots_adjust(left=.07, right=.985, bottom=.19, top=.73, wspace=.35)
            report.suptitle("Best observed rank over time", y=.99, fontsize=17, weight="bold")
            report.legend(handles=[Line2D([0], [0], color=COLORS[m], linewidth=2,
                            linestyle="--" if m in ("bury", "sqrt_bury") else "-", label=LABELS[m]) for m in ALL_METHODS],
                          loc="upper center", bbox_to_anchor=(.5, .93), ncol=5, frameon=False, fontsize=10.5,
                          columnspacing=1.1, handlelength=1.5)
            for ax, (title, graph_ids) in zip(report_axes, selected_groups):
                for method in ALL_METHODS:
                    data = [r for r in self.curves if r["panel"] == title and r["method"] == method]
                    xs = [r["seconds"] for r in data]
                    medians = [number(r["median"]) for r in data]
                    lows = [number(r["minimum"]) for r in data]
                    highs = [number(r["maximum"]) for r in data]
                    ax.step(xs, medians, where="post", color=COLORS[method], linewidth=1.7,
                            linestyle="--" if method in ("bury", "sqrt_bury") else "-",
                            zorder=4 if method in ("bury", "sqrt_bury") else 3)
                    ax.fill_between(xs, lows, highs, step="post", color=COLORS[method], alpha=.085, linewidth=0)
                self.axes_style(ax)
                ax.set_xscale("log"); ax.set_xlim(1e-5, 30); ax.set_ylim(bottom=0)
                ax.set_xticks([1e-5, 1e-3, .1, 30], ["10 μs", "1 ms", "0.1 s", "30 s"])
                ax.tick_params(labelsize=11)
                ax.set_xlabel("Solve time", fontsize=12)
                ax.set_ylabel("GF(2) cut rank", fontsize=12)
                report_title = title.replace("GF multiplier", "GF").replace("Evolution stage", "Evolution")
                ax.set_title(report_title, loc="left", weight="bold", fontsize=12)
            report.text(.07, .035, "Full-coverage medians; shading is observed min–max. Finished runs carry their incumbent forward.",
                        fontsize=10.3, color="#454545")
            self.save(report, report_stem, caption, ALL_METHODS, [g for _, gs in selected_groups for g in gs])

    def finish(self):
        sources = {name: digest(self.run / name) for name in ("inputs.tsv", "results.tsv", "summary.tsv", "baselines.tsv", "protocol.json")}
        task_hash = hashlib.sha256()
        for path in sorted((self.run / "tasks").glob("*.json")):
            task_hash.update(path.name.encode()); task_hash.update(path.read_bytes())
        manifest = dict(script_sha256=digest(__file__), source_sha256=sources, tasks_digest=task_hash.hexdigest(),
            python=sys.version, python_executable=sys.executable,
            matplotlib=matplotlib.__version__, numpy=np.__version__, figures=self.figures)
        with (self.output / "figure_manifest.json").open("x") as handle:
            json.dump(manifest, handle, indent=2, ensure_ascii=False)
        for name, rows in (("displayed_values.tsv", self.displayed), ("quality_time_values.tsv", self.curves)):
            with (self.output / name).open("x", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
                writer.writeheader(); writer.writerows(rows)
        print(json.dumps(dict(output=str(self.output), figures=len(self.figures), displayed_series=len(self.displayed),
                              curve_observations=len(self.curves)), indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    style()
    plotter = Plotter(args.run_dir, args.output_dir or args.run_dir / "figures")
    plotter.circuit_panels()
    plotter.circuit_panels(hybrid=True)
    plotter.evolution()
    plotter.remaining()
    plotter.synthetic()
    plotter.quality_time()
    plotter.finish()


if __name__ == "__main__":
    main()
