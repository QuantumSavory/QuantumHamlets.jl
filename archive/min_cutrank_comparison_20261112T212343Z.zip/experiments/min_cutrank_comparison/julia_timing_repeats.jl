#= Repeated timing supplement; never changes baselines or initializer charges.

Usage: julia --startup-file=no --project=.. experiments/min_cutrank_comparison/julia_timing_repeats.jl RUN_DIR

For every saved BURY membership, run one complete untimed warm solve, then three
timed solves with the original RNG seed reset before each. Verify every result
against the saved membership exactly. Measurements include GC; compilation is
reported explicitly rather than subtracted. Graph loading, RNG reset, result
validation, and table output are outside each measured solve.
=#
include("julia_baselines.jl")
using .MinCutrankJuliaBaselines
using QuantumHamlets, Random, Statistics, SHA, Dates

const M = MinCutrankJuliaBaselines

function repeat_timings(output)
    raw_path = joinpath(output, "timing_repeats.tsv")
    summary_path = joinpath(output, "timing_summary.tsv")
    metadata_path = joinpath(output, "timing_metadata.txt")
    for path in (raw_path, summary_path, metadata_path)
        ispath(path) && error("refusing to overwrite $path")
    end
    inputs = M.read_table(joinpath(output, "inputs.tsv"))
    by_id = Dict(row["id"] => row for row in inputs)
    baselines = M.read_table(joinpath(output, "baselines.tsv"))
    graph_cache = Dict{String,Any}()
    repeats = 3
    checks = 0
    start = Dates.now(Dates.UTC)
    M.warmup()
    M.fresh_file(raw_path) do raw
        M.fresh_file(summary_path) do summary
            M.write_row(raw, ("id", "method", "seed", "repetition", "wall_seconds", "gc_seconds",
                "compile_seconds", "recompile_seconds", "allocated_bytes", "labels_verified"))
            M.write_row(summary, ("id", "method", "seed", "repeats", "median_wall_seconds",
                "min_wall_seconds", "max_wall_seconds", "median_gc_seconds", "max_compile_seconds",
                "median_allocated_bytes"))
            for row in baselines
                id, method, seed = row["id"], row["method"], parse(Int, row["seed"])
                g = get!(graph_cache, id) do
                    M.load_input(output, by_id[id])
                end
                solve = method == "bury" ? M.ordinary : method == "sqrt_bury" ? M.sampled : error("invalid method")
                seed >= 0 && Random.seed!(seed)
                warm_p = solve(g)
                join(label == 2 ? '1' : '0' for label in membership(warm_p)) == row["labels"] ||
                    error("warm membership mismatch: $id/$method/$seed")
                checks += 1
                times, gc_times, compile_times, allocations = Float64[], Float64[], Float64[], Int[]
                for rep in 1:repeats
                    seed >= 0 && Random.seed!(seed)
                    measured = @timed solve(g)
                    p = measured.value
                    join(label == 2 ? '1' : '0' for label in membership(p)) == row["labels"] ||
                        error("timed membership mismatch: $id/$method/$seed/$rep")
                    checks += 1
                    M.write_row(raw, (id, method, seed, rep, measured.time, measured.gctime,
                        measured.compile_time, measured.recompile_time, measured.bytes, true))
                    push!(times, measured.time)
                    push!(gc_times, measured.gctime)
                    push!(compile_times, measured.compile_time)
                    push!(allocations, measured.bytes)
                end
                M.write_row(summary, (id, method, seed, repeats, median(times), minimum(times), maximum(times),
                    median(gc_times), maximum(compile_times), median(allocations)))
                println("TIMED\t", id, '\t', method, '\t', seed); flush(stdout)
            end
        end
    end
    M.fresh_file(metadata_path) do io
        println(io, "Started UTC: ", start)
        println(io, "Completed UTC: ", Dates.now(Dates.UTC))
        println(io, "Julia: ", VERSION, "; Julia threads: ", Threads.nthreads())
        println(io, "Saved baseline keys: ", length(baselines))
        println(io, "Timed repetitions per key: ", repeats)
        println(io, "Total timed repetitions: ", repeats * length(baselines))
        println(io, "Exact saved membership checks including one warm solve per key: ", checks)
        println(io, "Timing script SHA256: ", bytes2hex(sha256(read(@__FILE__))))
        println(io, "Baseline script SHA256: ", bytes2hex(sha256(read(joinpath(@__DIR__, "julia_baselines.jl")))))
        println(io, "Measurements are wall-clock observations during concurrent Python annealing work (up to two Python workers), not isolated microbenchmarks.")
        println(io, "Each case has an untimed full warm solve before three timed solves; the same seed is reset outside each solve timer.")
        println(io, "Compilation, recompilation, GC time and allocated bytes are recorded; no overhead is subtracted from wall time.")
        println(io, "Graph loading, RNG reset, membership verification and table output are excluded; all target search, seeded matching selection and winner rerun are included.")
        println(io, "Allocated bytes measure total Julia allocations per solve, not resident or peak process memory.")
        println(io, "Original baseline timing observations and initializer charges used by the annealing run are unchanged.")
    end
    println("TIMING_COMPLETE\t", repeats * length(baselines), "\tmembership_checks=", checks)
end

length(ARGS) == 1 || error("usage: julia_timing_repeats.jl RUN_DIR")
repeat_timings(abspath(only(ARGS)))
