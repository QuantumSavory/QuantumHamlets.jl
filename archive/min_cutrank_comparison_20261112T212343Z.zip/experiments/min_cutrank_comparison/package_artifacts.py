"""Package the final report, figures, data, and reproduction code without drafts."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    run = args.run_dir.resolve()
    root = Path(__file__).resolve().parent
    name = "QuantumHamlets_min_cutrank_comparison"
    for suffix in (".docx", ".pdf"):
        assert (run / "report" / (name + suffix)).is_file(), "Final report missing"
    assert json.loads((run / "table_validation.json").read_text())["julia_rescored_memberships"] == 3563
    assert json.loads((run / "schedule_sensitivity" / "comparison_audit.json").read_text())["status"] == "passed"
    assert (run / "figures_v2" / "visual_review.txt").is_file()
    files = [path for path in root.iterdir() if path.is_file() and path.suffix in (".py", ".jl", ".md")]
    for path in run.rglob("*"):
        if not path.is_file(): continue
        relative = path.relative_to(run)
        if relative.parts[0] == "figures": continue  # Superseded first visual draft remains on disk.
        if path.name == "upstream_source_86c1d8f.tar.gz": continue  # Bundle the code-only archive.
        if "__pycache__" in relative.parts: continue
        if relative.parts[0] == "report":
            if any(part.startswith(("rendered", "draft", "layout")) for part in relative.parts[1:-1]): continue
            if path.suffix == ".png": continue  # Internal page QA images are not deliverables.
        if path.suffix == ".zip": continue
        files.append(path)
    files = sorted(set(files))
    entries = [dict(path=str(path.relative_to(root.parent)), bytes=path.stat().st_size,
                    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in files]
    output = run / (name + "_artifacts.zip")
    with zipfile.ZipFile(output, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, entry in zip(files, entries):
            archive.write(path, entry["path"])
        archive.writestr("bundle_manifest.json", json.dumps(dict(files=entries,
            note="Final report and plots plus all study data and reproduction code. Superseded visual drafts and internal page-render QA images are omitted; they remain in the original workspace. Use the scripts from the QuantumHamlets repository as described in README.md."), indent=2))
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(entries) + 1
    print(json.dumps(dict(path=str(output), bytes=output.stat().st_size, files=len(entries),
                          sha256=hashlib.sha256(output.read_bytes()).hexdigest()), indent=2))


if __name__ == "__main__":
    main()
