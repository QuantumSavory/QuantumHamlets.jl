"""Turn immutable per-run JSON into complete, independently scored study tables."""
import argparse
import csv
import hashlib
import json
import statistics
from collections import Counter, defaultdict, deque
from pathlib import Path

from run_annealing import METHODS, BUDGETS, cut_rank, table


def write_tsv(path, rows):
    assert rows
    with path.open("x") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def secondary_costs(n, edges, flags):
    """Cardinality matching by BFS augmenting paths on the actual cut graph."""
    neighbors = [[] for _ in range(n)]
    edge_cut = 0
    for u, v in edges:
        if flags[u] != flags[v]:
            edge_cut += 1
            if flags[u]: neighbors[u].append(v)
            else: neighbors[v].append(u)
    mate = [-1] * n
    matching = 0
    for source in range(n):
        if not flags[source] or mate[source] != -1: continue
        queue, pred, end = deque([source]), {source: -1}, -1
        while queue and end == -1:
            u = queue.popleft()
            for v in neighbors[u]:
                if v in pred: continue
                pred[v] = u
                if mate[v] == -1:
                    end = v
                    break
                w = mate[v]
                if w not in pred:
                    pred[w] = v
                    queue.append(w)
        if end != -1:
            v = end
            while v != -1:
                u = pred[v]
                old_v = mate[u]
                mate[u], mate[v] = v, u
                v = old_v
            matching += 1
    return matching, edge_cut


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    run = args.run_dir
    inputs, baselines = table(run / "inputs.tsv"), table(run / "baselines.tsv")
    by_id = {row["id"]: row for row in inputs}
    tasks = [json.loads(p.read_text()) for p in sorted((run / "tasks").glob("*.json"))]
    expected = {(row["id"], method, seed) for row in inputs for method in METHODS for seed in range(10)}
    assert len(tasks) == len(expected) == 2010
    assert {(t["id"], t["method"], t["seed"]) for t in tasks} == expected
    edges = {row["id"]: [(int(e["u"]), int(e["v"])) for e in table(run / "edges" / (row["id"] + ".tsv"))] for row in inputs}
    cache, unique, results, status_rows = {}, [], [], []

    def score(graph_id, labels, declared_rank):
        key = (graph_id, labels)
        if key not in cache:
            n = int(by_id[graph_id]["n"])
            assert len(labels) == n and set(labels) <= {"0", "1"}
            flags = [x == "1" for x in labels]
            assert sorted([sum(flags), n - sum(flags)]) == [n // 2, n - n // 2]
            rank = cut_rank(n, edges[graph_id], flags)
            matching, edge_cut = secondary_costs(n, edges[graph_id], flags)
            assert 0 <= rank <= matching <= edge_cut
            membership_id = len(unique) + 1
            values = dict(membership_id=membership_id, rank=rank, matching=matching, edge_cut=edge_cut,
                          n_true=sum(flags), n_false=n - sum(flags))
            cache[key] = values
            unique.append(dict(membership_id=membership_id, id=graph_id, labels=labels,
                               rank=rank, matching=matching, edge_cut=edge_cut))
        assert cache[key]["rank"] == int(declared_rank)
        return cache[key]

    def result(graph_id, method, seed, view, budget, state, status, solve_seconds, **extra):
        meta = by_id[graph_id]
        row = {key: meta[key] for key in ("id", "collection", "family", "label", "parameter", "n", "m")}
        row.update(method=method, seed=seed, view=view, budget_seconds=budget, status=status,
                   rank="", matching="", edge_cut="", membership_id="", n_true="", n_false="",
                   candidate_seconds="", solve_seconds=solve_seconds, initializer_seconds=extra.get("initializer_seconds", 0),
                   completed_sweeps=extra.get("completed_sweeps", ""), python_cpu_seconds=extra.get("python_cpu_seconds", ""),
                   peak_process_rss_bytes=extra.get("peak_process_rss_bytes", ""))
        if state is not None:
            row.update(score(graph_id, state["labels"], state["rank"]))
            row["candidate_seconds"] = state["seconds"]
        results.append(row)

    for base in baselines:
        state = dict(rank=int(base["rank"]), labels=base["labels"], seconds=float(base["solve_seconds"]))
        values = score(base["id"], base["labels"], base["rank"])
        assert values["matching"] == int(base["matching"]) and values["edge_cut"] == int(base["edge_cut"])
        result(base["id"], base["method"], int(base["seed"]), "native", "", state, "completed", state["seconds"])
        for budget in BUDGETS:
            available = state["seconds"] <= budget
            result(base["id"], base["method"], int(base["seed"]), "incumbent", budget,
                   state if available else None, "available" if available else "unavailable", state["seconds"])

    for task in tasks:
        graph_id, method, seed = task["id"], task["method"], task["seed"]
        kwargs = {key: task.get(key, "") for key in
                  ("initializer_seconds", "completed_sweeps", "python_cpu_seconds", "peak_process_rss_bytes")}
        status_rows.append(dict(id=graph_id, method=method, seed=seed, status=task["status"],
            completed_sweeps=task.get("completed_sweeps", ""), solve_seconds=task.get("solve_seconds", ""),
            error=task.get("error") or ""))
        result(graph_id, method, seed, "native", "", task.get("final"), task["status"], task.get("solve_seconds", ""), **kwargs)
        for budget in BUDGETS:
            states = [event for event in task.get("incumbent_events", []) if event["seconds"] <= budget]
            state = states[-1] if states else None
            result(graph_id, method, seed, "incumbent", budget, state,
                   "available" if state else "unavailable", task.get("solve_seconds", ""), **kwargs)

    write_tsv(run / "results.tsv", results)
    write_tsv(run / "memberships.tsv", unique)
    write_tsv(run / "status.tsv", status_rows)
    groups = defaultdict(list)
    for row in results:
        groups[(row["id"], row["method"], row["view"], row["budget_seconds"])].append(row)
    summaries = []
    for (graph_id, method, view, budget), rows in groups.items():
        row = {key: by_id[graph_id][key] for key in ("id", "collection", "family", "label", "parameter", "n", "m")}
        valid = [r for r in rows if r["rank"] != ""]
        row.update(method=method, view=view, budget_seconds=budget, total=len(rows), valid=len(valid))
        for metric in ("rank", "matching", "edge_cut", "candidate_seconds", "solve_seconds"):
            values = [float(r[metric]) for r in valid]
            row.update({metric + "_median": statistics.median(values) if values else "",
                        metric + "_min": min(values) if values else "",
                        metric + "_max": max(values) if values else ""})
        summaries.append(row)
    write_tsv(run / "summary.tsv", summaries)
    lookup = {(r["id"], r["method"], r["view"], r["budget_seconds"]): r for r in summaries}
    comparison_groups = defaultdict(Counter)
    comparisons = []
    for item in inputs:
        graph_id = item["id"]
        for view, budget in [("native", ""), ("incumbent", 30.0)]:
            reference = lookup[graph_id, "random_sa", view, budget]
            for method in ("bury", "sqrt_bury", "bury_sa", "sqrt_sa"):
                value = lookup[graph_id, method, view, budget]
                full = value["valid"] == value["total"] and reference["valid"] == reference["total"]
                for metric in ("rank", "matching", "edge_cut"):
                    a, b = value[metric + "_median"], reference[metric + "_median"]
                    outcome = "unavailable" if not full else "lower" if a < b else "higher" if a > b else "tied"
                    comparisons.append(dict(id=graph_id, collection=item["collection"], family=item["family"],
                        method=method, reference="random_sa", view=view, budget_seconds=budget, metric=metric,
                        method_median=a, reference_median=b, method_valid=value["valid"], reference_valid=reference["valid"],
                        all_replicates_available=full, outcome=outcome))
                    for collection, family in ((item["collection"], item["family"]), (item["collection"], "ALL"),
                                                ("ALL_GRAPHS", "ALL")):
                        comparison_groups[(collection, family, method, view, budget, metric)][outcome] += 1
                    if item["collection"].startswith("graphml_"):
                        comparison_groups[("ALL_GRAPHML", "ALL", method, view, budget, metric)][outcome] += 1
    write_tsv(run / "comparisons.tsv", comparisons)
    family_rows = []
    for (collection, family, method, view, budget, metric), counts in comparison_groups.items():
        family_rows.append(dict(collection=collection, family=family, method=method, reference="random_sa",
            view=view, budget_seconds=budget, metric=metric, total=sum(counts.values()),
            **{x: counts[x] for x in ("lower", "tied", "higher", "unavailable")}))
    write_tsv(run / "family_summary.tsv", family_rows)
    overview = dict(inputs=len(inputs), baseline_runs=len(baselines), annealing_runs=len(tasks),
        native_status_counts=dict(Counter(t["status"] for t in tasks)), result_rows=len(results),
        unique_memberships=len(unique), summary_rows=len(summaries),
        native_final_worse_than_incumbent=sum(t.get("final") is not None and t["final"]["rank"] > t["incumbent_events"][-1]["rank"] for t in tasks),
        all_graphml_rank=[r for r in family_rows if r["collection"] == "ALL_GRAPHML" and r["metric"] == "rank"],
        all_graphs_rank=[r for r in family_rows if r["collection"] == "ALL_GRAPHS" and r["metric"] == "rank"])
    with (run / "overview.json").open("x") as handle: json.dump(overview, handle, indent=2)
    print(json.dumps(overview, indent=2))


if __name__ == "__main__":
    main()
