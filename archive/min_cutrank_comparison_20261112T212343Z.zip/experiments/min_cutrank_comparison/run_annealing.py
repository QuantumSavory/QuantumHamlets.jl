"""Pinned upstream annealing, with observed incumbents and explicit time limits.

The upstream tree is never edited. Each task runs in a fresh subprocess. A
GraphPartition subclass observes completed swaps; a temperature iterator observes
completed sweeps. Neither observer draws random numbers or changes proposals.
"""
import argparse
import concurrent.futures
import csv
import hashlib
import json
import os
import platform
import random
import resource
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
UPSTREAM_SHA = "86c1d8ff5d9b901983d9ad2254c8df0651e0219d"
METHODS = ("random_sa", "bury_sa", "sqrt_sa")
BUDGETS = (0.1, 1.0, 5.0, 30.0)


def table(path):
    with Path(path).open() as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def cut_rank(n, edges, flags):
    """Independent integer-bitset XOR elimination over GF(2)."""
    rows = [0] * n
    for u, v in edges:
        if flags[u] != flags[v]:
            if flags[u]: rows[u] |= 1 << v
            else: rows[v] |= 1 << u
    pivots = {}
    for u, belongs in enumerate(flags):
        if not belongs: continue
        row = rows[u]
        while row:
            pivot = row.bit_length() - 1
            if pivot in pivots: row ^= pivots[pivot]
            else:
                pivots[pivot] = row
                break
    return len(pivots)


def canon(flags):
    return [not x for x in flags] if sum(flags) > len(flags) // 2 else flags[:]


def flags_string(flags):
    return "".join("1" if x else "0" for x in flags)


class BudgetExpired(Exception):
    pass


def worker(run_dir, graph_id, method, seed):
    import numpy as np
    sys.path.insert(0, str(HERE / "upstream" / "src" / "min-cutrank"))
    from graph_partition import GraphPartition
    from cut_rank_annealing import cut_rank_annealing_row_formula

    metadata = next(row for row in table(run_dir / "inputs.tsv") if row["id"] == graph_id)
    n = int(metadata["n"])
    edge_path = run_dir / "edges" / f"{graph_id}.tsv"
    assert hashlib.sha256(edge_path.read_bytes()).hexdigest() == metadata["edge_sha256"]
    edges = [(int(row["u"]), int(row["v"])) for row in table(edge_path)]
    assert len(edges) == int(metadata["m"])
    initializer_seconds = 0.0
    initial_rank = None
    initial_flags = None
    if method != "random_sa":
        baseline_method, baseline_seed = ("bury", -1) if method == "bury_sa" else ("sqrt_bury", seed)
        base = next(row for row in table(run_dir / "baselines.tsv")
                    if row["id"] == graph_id and row["method"] == baseline_method and int(row["seed"]) == baseline_seed)
        initializer_seconds = float(base["solve_seconds"])
        initial_rank = int(base["rank"])
        initial_flags = canon([ch == "1" for ch in base["labels"]])

    protocol = json.loads((run_dir / "protocol.json").read_text())
    cap = protocol["per_run_wall_limit_seconds"]
    start_wall, start_cpu = time.perf_counter(), time.process_time()
    def elapsed(): return initializer_seconds + time.perf_counter() - start_wall
    def cpu(): return time.process_time() - start_cpu
    events, sweeps = [], []
    status, error, partition = "completed", None, None
    setup_seconds, final = None, None
    observed_swaps = 0

    def remember(rank, flags, when=None):
        nonlocal events
        when = elapsed() if when is None else when
        if not events or rank < events[-1]["rank"]:
            events.append(dict(seconds=when, python_cpu_seconds=cpu(), rank=int(rank), labels=flags_string(flags)))

    # A BURY solution already exists before Python builds annealing workspaces.
    if initial_flags is not None:
        remember(initial_rank, initial_flags, initializer_seconds)

    class ObservedPartition(GraphPartition):
        def apply_swap(self, row, column):
            nonlocal observed_swaps
            super().apply_swap(row, column)
            observed_swaps += 1
            remember(self.cut_rank, self.row_flag)

    def temperatures():
        for index, value in enumerate(np.linspace(1.0, 0.1, protocol["sweeps"])):
            yield value
            sweeps.append(dict(sweep=index + 1, seconds=elapsed(), rank=int(partition.cut_rank),
                               incumbent_rank=events[-1]["rank"]))

    def deadline(signum, frame):
        raise BudgetExpired()

    signal.signal(signal.SIGALRM, deadline)
    try:
        remaining = cap - initializer_seconds
        if remaining <= 0: raise BudgetExpired()
        signal.setitimer(signal.ITIMER_REAL, remaining)
        if initial_flags is None:
            # Separate, fixed streams for random initialization and annealing.
            initial_flags = [True] * (n // 2) + [False] * (n - n // 2)
            random.Random(100000 + seed).shuffle(initial_flags)
            initial_rank = cut_rank(n, edges, initial_flags)
            remember(initial_rank, initial_flags)
        adjacencies = [[0] * n for _ in range(n)]
        for u, v in edges:
            adjacencies[u][v] = adjacencies[v][u] = 1
        partition = ObservedPartition(adjacencies, initial_flags)
        assert partition.cut_rank == initial_rank
        setup_seconds = elapsed()
        random.seed(seed)
        cut_rank_annealing_row_formula(partition, temperatures(), False)
        final = dict(seconds=elapsed(), python_cpu_seconds=cpu(), rank=int(partition.cut_rank),
                     labels=flags_string(partition.row_flag))
    except BudgetExpired:
        status = "time_limit"
    except Exception:
        status, error = "error", traceback.format_exc()
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    solve_seconds, python_cpu_seconds = elapsed(), cpu()
    # Independently validate every saved membership after measurement ends.
    for saved in events + ([final] if final else []):
        flags = [ch == "1" for ch in saved["labels"]]
        assert len(flags) == n and sum(flags) == n // 2
        assert cut_rank(n, edges, flags) == saved["rank"]
    snapshots = []
    for budget in protocol["budgets_seconds"]:
        available = [event for event in events if event["seconds"] <= budget]
        snapshots.append(dict(budget=budget, candidate=available[-1] if available else None))
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform != "darwin": rss *= 1024
    return dict(id=graph_id, method=method, seed=seed, status=status, error=error,
        n=n, m=len(edges), initializer_seconds=initializer_seconds, setup_seconds=setup_seconds,
        solve_seconds=solve_seconds, python_cpu_seconds=python_cpu_seconds,
        peak_process_rss_bytes=rss, completed_sweeps=len(sweeps), accepted_swaps=observed_swaps,
        initial_rank=initial_rank, initial_labels=flags_string(initial_flags) if initial_flags else None,
        final=final, incumbent_events=events, sweep_trace=sweeps, budget_snapshots=snapshots)


def freeze_protocol(run_dir, workers):
    path = run_dir / "protocol.json"
    if path.exists(): return json.loads(path.read_text())
    sha = subprocess.check_output(["git", "-C", str(HERE / "upstream"), "rev-parse", "HEAD"], text=True).strip()
    assert sha == UPSTREAM_SHA
    assert not subprocess.check_output(["git", "-C", str(HERE / "upstream"), "status", "--porcelain"], text=True).strip()
    inputs = table(run_dir / "inputs.tsv")
    assert len(inputs) == 67
    import numpy as np
    protocol = dict(upstream_commit=sha, quantum_hamlets_commit=subprocess.check_output(
        ["git", "-C", str(HERE.parent.parent), "rev-parse", "HEAD"], text=True).strip(),
        graph_count=len(inputs), methods=list(METHODS), annealing_seeds=list(range(10)),
        random_initialization_seeds=list(range(100000, 100010)), sweeps=10,
        temperatures="numpy.linspace(1.0, 0.1, 10)", row_side="exactly floor(n/2), complement BURY labels when needed",
        per_run_wall_limit_seconds=30.0, subprocess_watchdog_seconds=75,
        budgets_seconds=list(BUDGETS), max_concurrent_workers=workers,
        task_order_seed=20261112, time_policy="Elapsed wall time includes dense conversion, workspace setup, observer overhead, and measured Julia initializer time for hybrids; excludes imports, file IO, and post-solve validation.",
        incumbent_policy="Keep first strictly lowest rank encountered, including initializer. A candidate counts at budget only if its recorded completion time does not exceed budget. Native final outputs require all 10 sweeps completed.",
        calibration="Excluded pilot, seed 271828: n132 ~0.32 CPU s /10 sweeps; n652 ~9.50 CPU s /10; n1772 setup1.43 CPU s, first sweep25.32 CPU s, interrupted at45 CPU s. Used solely to set30s cap; no quality-based tuning.",
        python=sys.version, python_executable=sys.executable, numpy=np.__version__, platform=platform.platform(),
        manifest_sha256=hashlib.sha256((run_dir / "inputs.tsv").read_bytes()).hexdigest(),
        baselines_sha256=hashlib.sha256((run_dir / "baselines.tsv").read_bytes()).hexdigest(),
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        created_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    with path.open("x") as handle: json.dump(protocol, handle, indent=2)
    return protocol


def launch_one(run_dir, task, protocol):
    graph_id, method, seed = task
    output = run_dir / "tasks" / f"{graph_id}__{method}__s{seed}.json"
    if output.exists():
        data = json.loads(output.read_text())
        assert (data["id"], data["method"], data["seed"]) == task
        return data, True
    command = [sys.executable, str(Path(__file__).resolve()), "worker", str(run_dir),
               "--id", graph_id, "--method", method, "--seed", str(seed)]
    env = os.environ.copy()
    env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1")
    try:
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=protocol["subprocess_watchdog_seconds"], env=env)
        if result.returncode: raise RuntimeError(result.stderr[-6000:])
        data = json.loads(result.stdout)
    except Exception as exc:
        data = dict(id=graph_id, method=method, seed=seed, status="worker_failure", error=str(exc))
    with output.open("x") as handle: json.dump(data, handle, separators=(",", ":"))
    return data, False


def collect(run_dir, workers):
    protocol = freeze_protocol(run_dir, workers)
    assert workers == protocol["max_concurrent_workers"]
    (run_dir / "tasks").mkdir(exist_ok=True)
    tasks = [(row["id"], method, seed) for row in table(run_dir / "inputs.tsv")
             for method in METHODS for seed in range(10)]
    random.Random(protocol["task_order_seed"]).shuffle(tasks)
    print(f"START {len(tasks)} tasks, {workers} workers", flush=True)
    count, statuses = 0, {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(launch_one, run_dir, task, protocol): task for task in tasks}
        for future in concurrent.futures.as_completed(futures):
            data, reused = future.result()
            count += 1
            statuses[data["status"]] = statuses.get(data["status"], 0) + 1
            if count % 10 == 0 or data["status"] not in ("completed", "time_limit"):
                print(json.dumps(dict(done=count, total=len(tasks), statuses=statuses,
                    latest=[data["id"], data["method"], data["seed"]], reused=reused)), flush=True)
    print("COMPLETE " + json.dumps(statuses), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("collect", "worker"))
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--id")
    parser.add_argument("--method", choices=METHODS)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    if args.mode == "collect": collect(run_dir, args.workers)
    else: print(json.dumps(worker(run_dir, args.id, args.method, args.seed)))


if __name__ == "__main__":
    main()
