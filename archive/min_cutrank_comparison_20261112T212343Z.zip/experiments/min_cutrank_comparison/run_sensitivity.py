#!/usr/bin/env python3
"""Predeclared 100-sweep schedule sensitivity using the unchanged main worker.

prepare freezes the selected structural strata before the main run completes.
collect refuses to start until every planned main task has a saved result. The
11 graphs x 3 methods x 3 seeds use the same 30-second wall cap and budget
checkpoints. A 100-step linear schedule changes cooling speed; it is not simply
90 additional sweeps appended to the 10-step schedule.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import concurrent.futures
import csv
import hashlib
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys
import time

from run_annealing import launch_one, table


HERE = Path(__file__).resolve().parent
SELECTED_IDS = [
    "graphml_evolution__k1",
    "graphml_evolution__k5",
    "graphml_reduced__gf2^4_mult",
    "graphml_initial__gf2^6_mult",
    "synthetic__grid_10",
] + [f"synthetic__er_n120_c{c}_s{seed}"
     for c in (2, 5) for seed in (1000, 1001, 1002)]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_table(path, rows, fields=None):
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def prepare(parent_dir):
    run_dir = parent_dir / "schedule_sensitivity"
    if run_dir.exists():
        raise SystemExit(f"Refusing to overwrite {run_dir}")
    parent_protocol = json.loads((parent_dir / "protocol.json").read_text())
    if sha256(parent_dir / "inputs.tsv") != parent_protocol["manifest_sha256"]:
        raise RuntimeError("Parent manifest changed after protocol freeze")
    if sha256(parent_dir / "baselines.tsv") != parent_protocol["baselines_sha256"]:
        raise RuntimeError("Parent baseline table changed after protocol freeze")
    parent_inputs = table(parent_dir / "inputs.tsv")
    selected = {row["id"]: row for row in parent_inputs if row["id"] in SELECTED_IDS}
    if set(selected) != set(SELECTED_IDS) or len(SELECTED_IDS) != 11:
        raise RuntimeError("Selected structural strata missing or duplicated")
    parent_task_count = len(list((parent_dir / "tasks").glob("*.json")))
    parent_planned = len(parent_inputs) * len(parent_protocol["methods"]) * len(parent_protocol["annealing_seeds"])
    if parent_task_count >= parent_planned:
        raise RuntimeError("This protocol must be frozen before main collection completes")
    run_dir.mkdir()
    (run_dir / "edges").mkdir()
    inputs = [selected[graph_id] for graph_id in SELECTED_IDS]
    baselines = [row for row in table(parent_dir / "baselines.tsv") if row["id"] in selected]
    if len(baselines) != 121:
        raise RuntimeError("Expected unchanged 11-row baseline bundle for each selected graph")
    write_table(run_dir / "inputs.tsv", inputs)
    write_table(run_dir / "baselines.tsv", baselines)
    for graph_id in SELECTED_IDS:
        source = parent_dir / "edges" / (graph_id + ".tsv")
        if sha256(source) != selected[graph_id]["edge_sha256"]:
            raise RuntimeError(f"Edge hash mismatch: {graph_id}")
        shutil.copyfile(source, run_dir / "edges" / source.name)
    protocol = dict(parent_protocol)
    protocol.update(
        study="Supplemental schedule sensitivity",
        parent_run="..",
        parent_protocol_sha256=sha256(parent_dir / "protocol.json"),
        parent_tasks_complete_at_freeze=parent_task_count,
        parent_planned_tasks=parent_planned,
        graph_count=len(inputs),
        selected_ids=SELECTED_IDS,
        selection_policy="Fixed structural strata: smallest/largest evolution stages; reduced GF(2^4) and initial GF(2^6) multipliers; largest included grid; all n=120 ER graphs at c=2 and c=5, graph seeds 1000:1002. No quality-outcome selection.",
        annealing_seeds=[0, 1, 2],
        random_initialization_seeds=[100000, 100001, 100002],
        sweeps=100,
        temperatures="numpy.linspace(1.0, 0.1, 100)",
        max_concurrent_workers=2,
        task_order_seed=20261113,
        incumbent_policy="Keep first strictly lowest rank encountered, including initializer. A candidate counts at budget only if its recorded completion time does not exceed budget. Native final outputs require all 100 sweeps completed.",
        inference_scope="A separate 11-graph, three-seed sensitivity study. Compare against the main 10-sweep study restricted to the identical graph/method/seed keys. The changed schedule cools more slowly and may be censored by the unchanged 30-second cap.",
        manifest_sha256=sha256(run_dir / "inputs.tsv"),
        baselines_sha256=sha256(run_dir / "baselines.tsv"),
        runner_sha256=sha256(HERE / "run_annealing.py"),
        sensitivity_runner_sha256=sha256(Path(__file__)),
        upstream_validation_reference="../upstream_validation.json",
        created_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
    with (run_dir / "protocol.json").open("x") as stream:
        json.dump(protocol, stream, indent=2)
    print(json.dumps({"status": "prepared", "run_dir": str(run_dir),
                      "graphs": len(inputs), "tasks": 99,
                      "main_tasks_finished_at_freeze": parent_task_count,
                      "workers_started": 0}, indent=2), flush=True)


def verify_main_complete(parent_dir):
    protocol = json.loads((parent_dir / "protocol.json").read_text())
    inputs = table(parent_dir / "inputs.tsv")
    expected = {(row["id"], method, seed) for row in inputs
                for method in protocol["methods"] for seed in protocol["annealing_seeds"]}
    saved = []
    for path in (parent_dir / "tasks").glob("*.json"):
        task = json.loads(path.read_text())
        saved.append((task["id"], task["method"], task["seed"]))
    if len(saved) != len(expected) or set(saved) != expected:
        raise RuntimeError(f"Main collection has {len(saved)}/{len(expected)} tasks; sensitivity workers cannot start")


def collect(parent_dir):
    run_dir = parent_dir / "schedule_sensitivity"
    protocol = json.loads((run_dir / "protocol.json").read_text())
    if sha256(HERE / "run_annealing.py") != protocol["runner_sha256"]:
        raise RuntimeError("Frozen main runner changed")
    if sha256(Path(__file__)) != protocol["sensitivity_runner_sha256"]:
        raise RuntimeError("Frozen sensitivity runner changed")
    if sha256(parent_dir / "protocol.json") != protocol["parent_protocol_sha256"]:
        raise RuntimeError("Frozen parent protocol changed")
    verify_main_complete(parent_dir)
    tasks = [(row["id"], method, seed) for row in table(run_dir / "inputs.tsv")
             for method in protocol["methods"] for seed in protocol["annealing_seeds"]]
    random.Random(protocol["task_order_seed"]).shuffle(tasks)
    (run_dir / "tasks").mkdir(exist_ok=True)
    statuses = Counter()
    with (run_dir / "collection.log").open("a") as log:
        def progress(message):
            print(message, flush=True)
            print(message, file=log, flush=True)
        progress(f"START {len(tasks)} sensitivity tasks, 2 workers, 100 sweeps, 30-second cap")
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(launch_one, run_dir, task, protocol) for task in tasks]
            for number, future in enumerate(concurrent.futures.as_completed(futures), 1):
                task, reused = future.result()
                statuses[task["status"]] += 1
                if number % 5 == 0 or task["status"] not in ("completed", "time_limit"):
                    progress(json.dumps(dict(done=number, total=len(tasks), statuses=dict(statuses),
                                             latest=[task["id"], task["method"], task["seed"]], reused=reused)))
        progress("COMPLETE " + json.dumps(dict(statuses)))


def load_tasks(run_dir):
    tasks = {}
    for path in (run_dir / "tasks").glob("*.json"):
        task = json.loads(path.read_text())
        key = (task["id"], task["method"], task["seed"])
        if key in tasks:
            raise RuntimeError(f"Duplicate task: {key}")
        tasks[key] = task
    return tasks


def summarize(parent_dir):
    run_dir = parent_dir / "schedule_sensitivity"
    protocol = json.loads((run_dir / "protocol.json").read_text())
    inputs = {row["id"]: row for row in table(run_dir / "inputs.tsv")}
    main_tasks = load_tasks(parent_dir)
    extra_tasks = load_tasks(run_dir)
    expected = {(graph_id, method, seed) for graph_id in inputs
                for method in protocol["methods"] for seed in protocol["annealing_seeds"]}
    if set(extra_tasks) != expected or not expected <= set(main_tasks):
        raise RuntimeError("Sensitivity or corresponding main task coverage incomplete")
    differences = []
    aggregate = defaultdict(Counter)
    for key in sorted(expected):
        main, extra = main_tasks[key], extra_tasks[key]
        graph_id, method, seed = key
        entry = inputs[graph_id]
        comparisons = [("native_final", main.get("final"), extra.get("final"))]
        main_snapshots = {row["budget"]: row["candidate"] for row in main.get("budget_snapshots", [])}
        extra_snapshots = {row["budget"]: row["candidate"] for row in extra.get("budget_snapshots", [])}
        comparisons += [(f"incumbent_{budget:g}s", main_snapshots.get(budget), extra_snapshots.get(budget))
                        for budget in protocol["budgets_seconds"]]
        for comparison, first, second in comparisons:
            available = first is not None and second is not None
            delta = second["rank"] - first["rank"] if available else ""
            outcome = ("lower" if delta < 0 else "higher" if delta > 0 else "tied") if available else "unavailable"
            differences.append(dict(
                id=graph_id, collection=entry["collection"], family=entry["family"], n=entry["n"],
                method=method, seed=seed, comparison=comparison,
                main_status=main["status"], sensitivity_status=extra["status"],
                main_rank=first["rank"] if first else "", sensitivity_rank=second["rank"] if second else "",
                sensitivity_minus_main=delta, outcome=outcome,
                main_candidate_seconds=first["seconds"] if first else "",
                sensitivity_candidate_seconds=second["seconds"] if second else "",
            ))
            aggregate[(entry["collection"], entry["family"], method, comparison)][outcome] += 1
    summaries = []
    for (collection, family, method, comparison), count in sorted(aggregate.items()):
        summaries.append(dict(collection=collection, family=family, method=method, comparison=comparison,
                              lower=count["lower"], tied=count["tied"], higher=count["higher"],
                              unavailable=count["unavailable"], total=sum(count.values())))
    write_table(run_dir / "schedule_differences.tsv", differences)
    write_table(run_dir / "schedule_summary.tsv", summaries)
    overall = defaultdict(Counter)
    for row in differences:
        overall[(row["method"], row["comparison"])][row["outcome"]] += 1
    result = dict(
        graph_count=len(inputs), task_count=len(extra_tasks),
        statuses=dict(Counter(row["status"] for row in extra_tasks.values())),
        native_available_pairs=sum(row["comparison"] == "native_final" and row["outcome"] != "unavailable"
                                   for row in differences),
        comparisons=[dict(method=method, comparison=comparison, **dict(count))
                     for (method, comparison), count in sorted(overall.items())],
        interpretation="Delta is 100-sweep rank minus 10-sweep rank on identical graph/initializer/annealing-seed keys. Negative is lower rank. Native finals require completion of each full schedule; incomplete outputs are unavailable. Incumbents use strict elapsed-time availability. A slower cooling schedule is not a continuation of the 10-sweep trajectory.",
        inference_scope=protocol["inference_scope"],
        protocol_sha256=sha256(run_dir / "protocol.json"),
    )
    with (run_dir / "schedule_comparison.json").open("x") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "collect", "summarize"))
    parser.add_argument("parent_run_dir", type=Path)
    args = parser.parse_args()
    parent_dir = args.parent_run_dir.resolve()
    {"prepare": prepare, "collect": collect, "summarize": summarize}[args.mode](parent_dir)


if __name__ == "__main__":
    main()
