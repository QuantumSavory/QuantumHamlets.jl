"""Fresh-process peak RSS probes on the largest study graph (macOS time -l).

This measures each entire Julia process, including package loading, compilation,
small odd/even warm solves, graph loading, one largest-graph solve and validation.
It is not incremental algorithm memory and not allocated bytes per operation.
"""
from __future__ import annotations

import csv
import pathlib
import re
import subprocess
import sys


JULIA_CODE = r'''
include("experiments/min_cutrank_comparison/julia_baselines.jl")
using .MinCutrankJuliaBaselines, QuantumHamlets, Graphs, Random
M = MinCutrankJuliaBaselines
output, method = ARGS
inputs = M.read_table(joinpath(output, "inputs.tsv"))
row = inputs[argmax([parse(Int, r["n"]) for r in inputs])]
g = M.load_input(output, row)
solve = method == "bury" ? M.ordinary : M.sampled
seed = method == "bury" ? -1 : 0
for n in (10, 11)
    Random.seed!(0)
    solve(path_graph(n))
end
Random.seed!(0)
result = @timed solve(g)
labels = join(label == 2 ? '1' : '0' for label in membership(result.value))
saved = only(filter(r -> r["id"] == row["id"] && r["method"] == method && parse(Int, r["seed"]) == seed,
    M.read_table(joinpath(output, "baselines.tsv"))))
labels == saved["labels"] || error("saved membership mismatch")
println("RESULT\t", row["id"], '\t', method, '\t', seed, '\t', row["n"], '\t', result.time,
    '\t', result.bytes, '\t', result.gctime, '\t', result.compile_time)
'''


def main() -> None:
    output = pathlib.Path(sys.argv[1]).resolve()
    destination = output / "julia_process_memory.tsv"
    if destination.exists():
        raise FileExistsError(destination)
    root = pathlib.Path(__file__).resolve().parents[2]
    records = []
    for method in ("bury", "sqrt_bury"):
        stdout_path = output / f"memory_{method}.stdout.log"
        stderr_path = output / f"memory_{method}.stderr.log"
        with stdout_path.open("x") as out, stderr_path.open("x") as err:
            subprocess.run(
                ["/usr/bin/time", "-l", "julia", "--startup-file=no", "--project=..", "-e", JULIA_CODE, str(output), method],
                cwd=root, stdout=out, stderr=err, check=True, timeout=180,
            )
        stderr = stderr_path.read_text()
        peak = int(re.search(r"(\d+)\s+maximum resident set size", stderr).group(1))
        process_seconds = float(re.search(r"([\d.]+) real\s+[\d.]+ user", stderr).group(1))
        result = next(line.split("\t") for line in stdout_path.read_text().splitlines() if line.startswith("RESULT\t"))
        records.append(dict(zip(
            ("id", "method", "seed", "n", "solve_seconds", "solve_allocated_bytes", "solve_gc_seconds", "solve_compile_seconds"), result[1:]
        ), peak_process_rss_bytes=peak, process_wall_seconds=process_seconds,
            memory_scope="whole fresh Julia process including package loading and validation"))
    with destination.open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(records)
    for record in records:
        print(record)


if __name__ == "__main__":
    main()
