"""Graph export, BURY baselines, and independent Julia rescoring for min-cutrank.

Run from the package root using the existing parent environment:
    julia --startup-file=no --project=.. experiments/min_cutrank_comparison/julia_baselines.jl export RUN_DIR
    julia --startup-file=no --project=.. experiments/min_cutrank_comparison/julia_baselines.jl run RUN_DIR
    julia --startup-file=no --project=.. experiments/min_cutrank_comparison/julia_baselines.jl score RUN_DIR MEMBERSHIPS.tsv SCORES.tsv

All writers refuse to replace existing files. The run command reads the manifest,
so predeclared synthetic fixtures may be appended after GraphML export. Edge
files use zero-based vertex IDs; output labels are binary strings in that order.
"""
module MinCutrankJuliaBaselines

using QuantumHamlets, Graphs, GraphIO.GraphML, EzXML, Random, SHA, Dates

const Q = QuantumHamlets
const ROOT = normpath(joinpath(@__DIR__, "../.."))
const INPUT_FIELDS = ("id", "collection", "family", "label", "parameter", "n", "m", "source_sha256", "edge_sha256")
const BASELINE_FIELDS = ("id", "method", "seed", "rank", "matching", "edge_cut", "solve_seconds", "bytes", "labels", "n_true", "n_false")

function write_row(io, values)
    println(io, join(values, '\t'))
    flush(io)
end

function fresh_file(path, writer)
    ispath(path) && error("refusing to overwrite $path")
    mkpath(dirname(path))
    open(writer, path, "w")
end
fresh_file(writer::Function, path) = fresh_file(path, writer)

function read_table(path)
    lines = readlines(path)
    isempty(lines) && error("empty table: $path")
    fields = split(first(lines), '\t'; keepempty=true)
    length(unique(fields)) == length(fields) || error("duplicate columns: $path")
    rows = Dict{String,String}[]
    for (i, line) in enumerate(lines[2:end])
        values = split(line, '\t'; keepempty=true)
        length(fields) == length(values) || error("wrong column count at $path:$(i+1)")
        push!(rows, Dict(String(k) => String(v) for (k, v) in zip(fields, values)))
    end
    return rows
end

function family_parameter(collection, name)
    if collection == "graphml_evolution"
        found = match(r"^k(\d+)$", name)
        isnothing(found) || return ("evolution", only(found.captures))
    end
    for (pattern, family) in ((r"^gf2\^(\d+)_mult$", "gf_multiplier"),
                              (r"^barenco_tof_(\d+)$", "barenco_toffoli"),
                              (r"^tof_(\d+)$", "toffoli"))
        found = match(pattern, name)
        isnothing(found) || return (family, only(found.captures))
    end
    found = match(r"^(.*?)[_]?([0-9]+)$", name)
    isnothing(found) && return (name, "")
    return (rstrip(found.captures[1], '_'), found.captures[2])
end

function export_graphml(output)
    manifest_path = joinpath(output, "inputs.tsv")
    ispath(manifest_path) && error("refusing to overwrite $manifest_path")
    previous = read_table(joinpath(ROOT, "resources/figs/graphml_families/run_20261112T145558Z/inputs.tsv"))
    previous_by_id = Dict(row["collection"] * "__" * row["graph"] => row for row in previous)
    count = 0
    fresh_file(manifest_path) do io
        write_row(io, INPUT_FIELDS)
        for collection in ("graphml_initial", "graphml_reduced", "graphml_evolution")
            directory = joinpath(ROOT, "resources", collection)
            for path in sort(filter(path -> endswith(path, ".graphml"), readdir(directory; join=true)))
                name = splitext(basename(path))[1]
                id = collection * "__" * name
                g = loadgraph(path, GraphMLFormat())
                g isa Graphs.Graph || error("expected a simple undirected graph: $path")
                n, m = nv(g), ne(g)
                digest = bytes2hex(sha256(read(path)))
                prior = previous_by_id[id]
                (parse(Int, prior["n"]), parse(Int, prior["m"]), prior["sha256"]) == (n, m, digest) ||
                    error("GraphML differs from frozen study: $id")

                # Check the independent archived topology rather than replacing it.
                historical = readlines(joinpath(ROOT, "experiments/graphml_bury/inventory/topology", id * ".tsv"))
                parse.(Int, split(first(historical), '\t')) == [n, m] || error("historical size mismatch: $id")
                historical_edges = Set(Tuple(parse.(Int, split(line, '\t'))) for line in historical[2:end])
                Set((src(e), dst(e)) for e in edges(g)) == historical_edges || error("historical topology mismatch: $id")

                edge_path = joinpath(output, "edges", id * ".tsv")
                fresh_file(edge_path) do edge_io
                    write_row(edge_io, ("u", "v"))
                    for e in edges(g)
                        write_row(edge_io, (src(e) - 1, dst(e) - 1))
                    end
                end
                family, parameter = family_parameter(collection, name)
                write_row(io, (id, collection, family, name, parameter, n, m, digest,
                    bytes2hex(sha256(read(edge_path)))))
                count += 1
                println("EXPORTED\t", id, '\t', n, '\t', m); flush(stdout)
            end
        end
    end
    count == 45 || error("expected exactly 45 GraphML inputs, got $count")
    println("EXPORT_COMPLETE\t", count)
end

function load_input(output, row)
    n, m = parse(Int, row["n"]), parse(Int, row["m"])
    path = joinpath(output, "edges", row["id"] * ".tsv")
    bytes2hex(sha256(read(path))) == row["edge_sha256"] || error("edge hash mismatch: $(row["id"])")
    edge_rows = read_table(path)
    length(edge_rows) == m || error("edge count mismatch: $(row["id"])")
    g = SimpleGraph(n)
    for edge in edge_rows
        u, v = parse(Int, edge["u"]) + 1, parse(Int, edge["v"]) + 1
        1 <= u < v <= n || error("invalid canonical edge in $path")
        add_edge!(g, u, v) || error("duplicate edge in $path")
    end
    ne(g) == m || error("wrong graph edge count: $path")
    return g
end

ordinary(g) = bipartition_graph(g; objective=pairwise_cut_rank, backend=:heap)

function sampled(g)
    reg, _ = redirect_stdout(devnull) do
        Q.bury_not_balanced_bipartition(g, fld(nv(g), 2), cld(nv(g), 2);
            bury_v=Q.bury_seeded, cost_f=Q.cut_rank_cost, backend=:heap)
    end
    return GraphPartition(reg; nparts=2)
end

function score_partition(g, p)
    sizes = partition_sizes(p)
    length(p) == nv(g) && p.nparts == 2 || error("invalid partition dimensions")
    sort(sizes) == [fld(nv(g), 2), cld(nv(g), 2)] || error("partition is not exactly near-balanced")
    rank, matching, cut = pairwise_cut_rank(g, p), matching_cost(g, p), edge_cut_cost(g, p)
    0 <= rank <= matching <= cut || error("rank/matching/edge-cut bounds failed")
    labels = join(label == 2 ? '1' : '0' for label in membership(p))
    return (rank=rank, matching=matching, edge_cut=cut, labels=labels,
        n_true=sizes[2], n_false=sizes[1])
end

function historical_ranks()
    previous = read_table(joinpath(ROOT, "resources/figs/graphml_families/run_20261112T145558Z/results.tsv"))
    expected = Dict{Tuple{String,String,Int},Int}()
    for row in previous
        row["parts"] == "2" && row["objective"] == "rank" || continue
        method = row["algorithm"] == "BURY" ? "bury" : row["algorithm"] == "BURY_seeded" ? "sqrt_bury" : nothing
        isnothing(method) && continue
        seed = method == "bury" ? -1 : parse(Int, row["seed"])
        expected[(row["collection"] * "__" * row["graph"], method, seed)] = parse(Int, row["cost"])
    end
    return expected
end

function warmup()
    for n in (10, 11)
        g = path_graph(n)
        score_partition(g, ordinary(g))
        Random.seed!(777)
        score_partition(g, sampled(g))
        @timed ordinary(g)
        @timed sampled(g)
    end
end

function run_baselines(output)
    path = joinpath(output, "baselines.tsv")
    ispath(path) && error("refusing to overwrite $path")
    inputs = read_table(joinpath(output, "inputs.tsv"))
    ids = [row["id"] for row in inputs]
    length(ids) == length(unique(ids)) || error("duplicate graph IDs")
    expected = historical_ranks()
    warmup()
    println("READY\tJulia ", VERSION, "\tthreads=", Threads.nthreads()); flush(stdout)
    count, historical_checks = 0, 0
    fresh_file(path) do io
        write_row(io, BASELINE_FIELDS)
        for row in inputs
            g = load_input(output, row)
            original = copy(g)
            for method in ("bury", "sqrt_bury")
                for seed in (method == "bury" ? [-1] : collect(0:9))
                    println("STAGE\t", row["id"], '\t', method, '\t', seed); flush(stdout)
                    seed >= 0 && Random.seed!(seed)
                    measured = method == "bury" ? (@timed ordinary(g)) : (@timed sampled(g))
                    p = measured.value
                    scores = score_partition(g, p)
                    key = (row["id"], method, seed)
                    if haskey(expected, key)
                        scores.rank == expected[key] || error("historical rank mismatch for $key")
                        historical_checks += 1
                    end
                    g == original || error("partitioner changed the graph")
                    write_row(io, (row["id"], method, seed, scores.rank, scores.matching,
                        scores.edge_cut, measured.time, measured.bytes, scores.labels,
                        scores.n_true, scores.n_false))
                    count += 1
                end
            end
        end
    end
    fresh_file(joinpath(output, "julia_validation.txt")) do io
        println(io, "Julia version: ", VERSION)
        println(io, "Julia threads: ", Threads.nthreads())
        println(io, "QuantumHamlets version: ", Base.pkgversion(QuantumHamlets))
        println(io, "Graphs version: ", Base.pkgversion(Graphs))
        println(io, "Inputs: ", length(inputs))
        println(io, "Baseline memberships: ", count)
        println(io, "Historical rank comparisons passed: ", historical_checks)
        println(io, "Every membership validated for exact floor/ceiling sizes and rank <= matching <= edge cut.")
        println(io, "Every loaded edge file hash checked; graph equality checked after every solve.")
        println(io, "solve_seconds measures a complete warmed solve, excluding RNG reset, graph loading, independent rescoring, and output serialization.")
        println(io, "Sampled sqrt solve includes both targets where odd, matching-selected inner seed trials, winner rerun, and legacy registry construction.")
        println(io, "bytes is Julia allocated bytes during the solve, not peak process memory.")
        println(io, "The single deterministic timing and ten sampled timings are observations, not a microbenchmark distribution.")
    end
    println("BASELINES_COMPLETE\t", count, "\thistorical=", historical_checks)
end

function score_memberships(output, input_path, output_path)
    inputs = read_table(joinpath(output, "inputs.tsv"))
    by_id = Dict(row["id"] => row for row in inputs)
    graph_cache = Dict{String,SimpleGraph{Int}}()
    rows = read_table(input_path)
    fresh_file(output_path) do io
        write_row(io, ("row_number", "id", "method", "seed", "julia_rank", "julia_matching", "julia_edge_cut", "n_true", "n_false"))
        for (i, row) in enumerate(rows)
            id = row["id"]
            g = get!(graph_cache, id) do
                load_input(output, by_id[id])
            end
            raw = row["labels"]
            length(raw) == nv(g) && all(in(('0', '1')), raw) || error("invalid labels at row $i")
            p = GraphPartition([c == '1' ? 2 : 1 for c in raw]; nparts=2)
            scores = score_partition(g, p)
            for (field, value) in (("rank", scores.rank), ("matching", scores.matching), ("edge_cut", scores.edge_cut))
                haskey(row, field) && !isempty(row[field]) && parse(Int, row[field]) != value && error("$field mismatch at row $i")
            end
            write_row(io, (i, id, get(row, "method", ""), get(row, "seed", ""), scores.rank,
                scores.matching, scores.edge_cut, scores.n_true, scores.n_false))
        end
    end
    println("RESCORING_COMPLETE\t", length(rows))
end

function main(args)
    length(args) >= 2 || error("usage: julia_baselines.jl export|run|score RUN_DIR [MEMBERSHIPS.tsv SCORES.tsv]")
    mode, output = args[1], abspath(args[2])
    if mode == "export"
        length(args) == 2 || error("export expects RUN_DIR")
        export_graphml(output)
    elseif mode == "run"
        length(args) == 2 || error("run expects RUN_DIR")
        run_baselines(output)
    elseif mode == "score"
        length(args) == 4 || error("score expects RUN_DIR MEMBERSHIPS.tsv SCORES.tsv")
        score_memberships(output, args[3], args[4])
    else
        error("unknown mode $mode")
    end
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    MinCutrankJuliaBaselines.main(ARGS)
end
