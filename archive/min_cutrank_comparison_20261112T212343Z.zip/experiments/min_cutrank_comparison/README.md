# Balanced BURY and min-cutrank comparison

This experiment compares QuantumHamlets BURY bipartitions with the Python
`min-cutrank` annealer at pinned upstream commit
`86c1d8ff5d9b901983d9ad2254c8df0651e0219d`. It also measures annealing initialized
by ordinary and sampled sqrt-seeded BURY. Production package code and all older
GraphML studies are unchanged.

The current experiment directory is recorded in `CURRENT_RUN.txt`. Its
`protocol.json` freezes inputs, commits, seeds, schedules, budgets, and the runner
hash before data collection. `inputs.tsv` and `edges/` retain the exact graph
topologies; every output includes reconstructable memberships.

## Report and plots

- [Findings report PDF](run_20261112T161827Z/report/QuantumHamlets_min_cutrank_comparison.pdf)
- [Editable Word report](run_20261112T161827Z/report/QuantumHamlets_min_cutrank_comparison.docx)
- [Report, plots, data, and reproduction code bundle](run_20261112T161827Z/QuantumHamlets_min_cutrank_comparison_artifacts.zip)

The final plots are in `run_20261112T161827Z/figures_v2/`. Each has PNG, SVG,
and PDF versions. The earlier `figures/` directory is a preserved visual draft.

| Figure | PNG | SVG |
| --- | --- | --- |
| Multiplier, Toffoli, and Barenco native rank | [View](run_20261112T161827Z/figures_v2/circuit_rank_native.png) | [Vector](run_20261112T161827Z/figures_v2/circuit_rank_native.svg) |
| Initializers and 30-second incumbent rank | [View](run_20261112T161827Z/figures_v2/hybrid_rank_30s.png) | [Vector](run_20261112T161827Z/figures_v2/hybrid_rank_30s.svg) |
| All evolution stages | [View](run_20261112T161827Z/figures_v2/evolution_rank.png) | [Vector](run_20261112T161827Z/figures_v2/evolution_rank.svg) |
| Every remaining circuit family | [View](run_20261112T161827Z/figures_v2/remaining_circuits_native.png) | [Vector](run_20261112T161827Z/figures_v2/remaining_circuits_native.svg) |
| Grids and sparse random graphs | [View](run_20261112T161827Z/figures_v2/synthetic_rank_native.png) | [Vector](run_20261112T161827Z/figures_v2/synthetic_rank_native.svg) |
| Rank versus elapsed solve time | [View](run_20261112T161827Z/figures_v2/quality_vs_time.png) | [Vector](run_20261112T161827Z/figures_v2/quality_vs_time.svg) |

Fourteen additional `report_` variants improve readability when embedded in
the document. Plot provenance, numeric-value checks, and visual review are
retained in the final figure directory.

## Main study findings

The completed main study is
[`run_20261112T161827Z`](run_20261112T161827Z/). It contains 67 graphs, 737 BURY
baseline memberships, and 2,010 annealing runs. Of the annealing runs, 1,950
finished all ten sweeps and 60 reached the 30-second limit. All 60 limits are
the ten seeds of all three annealing initializers on evolution stages 4 and 5.
There were no execution errors. All 3,563 distinct published memberships were
independently rescored in Python and Julia, including rank, matching, and cut.

Across the **45 circuit graphs**, compare each method's median rank with
random-start min-cutrank. The entries below are **lower / tied / higher /
unavailable**. Native comparisons require all ten annealing runs to finish;
30-second incumbents include retained candidates from capped runs.

| Method | Native outputs | Incumbents available by 30 seconds |
| --- | --- | --- |
| Ordinary BURY | 15 / 3 / 25 / 2 | 16 / 3 / 26 / 0 |
| Sampled sqrt BURY | 32 / 6 / 5 / 2 | 34 / 6 / 5 / 0 |
| BURY plus annealing | 26 / 10 / 7 / 2 | 29 / 8 / 8 / 0 |
| Sqrt BURY plus annealing | 38 / 3 / 2 / 2 | 40 / 4 / 1 / 0 |

These are ten-sweep fixture measurements using the upstream example schedule,
not a claim about fully tuned annealing or unlimited restarts. Sampled sqrt BURY is lower on all 20
initial circuit graphs, but has losses among the reduced graphs and at evolution
stage 2. The one 30-second sqrt-initialized hybrid loss is reduced `vbe_adder_3`
(median 3.5 versus random-start incumbent 3). On evolution stage 5, median
30-second ranks are ordinary 153, sqrt 85, random-start annealing 204,
ordinary-initialized annealing 128.5, and sqrt-initialized annealing 59.5.
No ten-sweep annealing final output is available there.

Sqrt-initialized annealing improves on its own initializer in 186 of 450 circuit
replicates and ties it in 264. Its incumbent policy prevents regression by
construction; the improvement count is the substantive observation. Native
annealing can regress: 236 of 1,950 completed runs finish above an earlier
incumbent. The raw native outputs are retained rather than replaced by those
incumbents.

All four grid instances have median ranks 4, 6, 8, and 10 for all methods; their
larger-grid optimality is not assumed. The sparse random families retain
counterexamples: across all 22 synthetic inputs, sqrt BURY has 7 lower,
12 tied, and 3 higher native medians than random-start annealing. Numerical
results for all families and secondary objectives are in
[`summary.tsv`](run_20261112T161827Z/summary.tsv),
[`family_summary.tsv`](run_20261112T161827Z/family_summary.tsv), and
[`results.tsv`](run_20261112T161827Z/results.tsv).

## Schedule sensitivity

The separately predeclared [100-sweep supplement](run_20261112T161827Z/schedule_sensitivity/)
covers 11 structural representatives and seeds 0 through 2: 99 runs with the
same three initializers and 30-second cap. It completes 81 schedules and caps
18 (all initial GF(2^6) and evolution stage 5 runs), with no errors. Compare
only identical graph, initializer, and seed keys with the main ten-sweep run:

| Initializer | 100-sweep rank lower / tied / higher at 30 seconds |
| --- | --- |
| Random | 18 / 13 / 2 |
| Ordinary BURY | 9 / 22 / 2 |
| Sqrt BURY | 6 / 25 / 2 |

The longer, slower-cooling schedule often helps, but changes the trajectory and
does not uniformly improve the result. It also changes relative rankings:
across these 11 graphs and three seeds, the sqrt hybrid versus random-start
incumbent comparison changes from 7 lower / 4 tied / 0 higher with ten sweeps
to 6 lower / 3 tied / 2 higher with 100. Both added losses are sparse c=2,
n=120 fixtures (graph seeds 1001 and 1002). Thus the main corpus counts are
specific to the tested schedule and are not a claim against fully tuned
min-cutrank. This supplement is a different cooling schedule, not a continuation
of the original ten sweeps, and its 11 graphs do not replace the main 67-graph
coverage. The [paired differences](run_20261112T161827Z/schedule_sensitivity/schedule_differences.tsv)
and [complete summary](run_20261112T161827Z/schedule_sensitivity/schedule_comparison.json)
retain native-final exclusions and every time budget.

## Questions and scope

- How do the methods compare in GF(2) cut rank under exactly equal capacities,
  or capacities differing by one for odd graphs?
- What partitions are available within declared elapsed-time budgets?
- Does BURY provide useful initial partitions for the annealer?
- How do matching and edge cut change on the same rank-selected partitions?

All 45 existing GraphML inputs are included: 20 initial, 20 reduced, five
evolution stages. Four square grids (4, 6, 8, 10 vertices per side) and 18
Erdos-Renyi graphs supplement them. The latter use n=40,80,120; p=c/n for c=2,5;
and three graph RNG seeds, 1000 through 1002, at every size/density. They are not
conditioned on connectivity. Generated topology is saved once and shared by
all methods. Graph seeds are distinct from algorithm seeds. The same three
graph seeds are reused across sizes and densities: in particular the c=2 graph
is a subgraph of its c=5 counterpart at a fixed n/seed. These are three RNG
streams per stratum, not 18 independent population samples.

## Method definitions

| Method ID | Construction |
| --- | --- |
| `bury` | Ordinary heap BURY, floor/ceiling targets, outer GF(2) rank selection |
| `sqrt_bury` | Existing sampled sqrt seeding, with replacement, matching-selected inner seeds, outer rank target selection |
| `random_sa` | Upstream incremental row-formula annealer, random fixed-size initialization |
| `bury_sa` | Same annealer initialized by the saved ordinary BURY partition |
| `sqrt_sa` | Same annealer initialized by that replicate's saved sqrt BURY partition |

The BURY objective selects among its generated target candidates; it does not
change the internal greedy construction. Sqrt BURY retains its existing
ceil(sqrt(n)) sample policy, first-best seed ties, and winner rerun. This is not
the minimum-degree residual multipartition seeder. All reported results are
bipartitions; no recursive multipartition adaptation is included.

BURY may select either labeled target size on odd graphs. Before annealing,
complement its Boolean membership when necessary so the annealer's row side
always has floor(n/2) vertices. This preserves the partition and all symmetric
cut costs. Row orientation matters to the annealing trajectory, so this policy
is held fixed. All accepted annealing operations swap one vertex from each side.

The main study uses algorithm seeds 0 through 9. Random initial partitions use
a separate Python RNG with seeds 100000 through 100009. Annealing resets Python's
global RNG to the corresponding algorithm seed. Equal integer seeds across Julia
and Python are not common random numbers. Ordinary BURY is recorded once per
graph, with no artificial stochastic replication.

## Native outputs and observed incumbents

The main schedule is ten linearly spaced temperatures from 1.0 to 0.1, using
upstream `cut_rank_annealing_row_formula`. A subclass observes completed swaps
and a temperature iterator observes completed sweeps. The pinned upstream tree
is unmodified; the observers do not draw random numbers or alter proposals.

The native result is the final state after all ten sweeps, including any final
uphill move. It is unavailable if the run does not finish within its resource
limit. A separate instrumented incumbent retains the first strictly lowest rank
seen, including the initializer. It is evaluated at 0.1, 1, 5, and 30 seconds.
An incumbent counts at a budget only if its recorded availability timestamp is
no later than that budget. This is an explicitly labeled wrapper policy.

Each complete solve has a 30-second elapsed-wall-time limit, with a 75-second
external subprocess watchdog. A signal may interrupt an upstream mutable
workspace; interrupted workspaces are discarded and only previously completed,
copied, independently validated memberships remain eligible. Limits and errors
are retained. No timeout is counted as a native-quality loss or assigned an
invented final rank. Main native win/tie/loss summaries require every planned
replicate of both comparators to be available; partially completed medians, when
shown, carry their completion counts.

Timing starts after imports and topology-file reads, but includes dense
adjacency construction, the upstream workspace, observer overhead, and initial
rank evaluation for random starts. Hybrid totals add a separately measured
complete Julia initializer solve to the observed Python duration; they are
composed costs, not a fresh integrated pipeline measurement. The existing BURY candidate is available
after that initializer cost, before annealing workspace setup. Independent
post-solve scoring and output serialization are excluded. Python CPU time is
also recorded, but does not include the Julia initializer.

Collection runs at most two Python subprocesses concurrently and randomizes
task order using seed 20261112. Wall times therefore describe this implementation
and collection environment, including scheduling/contention; they are not an
algorithmic complexity comparison or a precise language-independent speedup.
There is one invocation per replicate, not unlimited restarts until a budget
expires. Short solves retain their incumbent for later budgets.

`timing_repeats.tsv` separately measures warmed BURY solves three times per
saved graph/method/seed, verifying exact membership each time. It retains GC,
compilation, and allocation measurements. These repeated timings do not replace
the original initializer charges used by the main study. Julia allocated bytes
are not comparable to process RSS. Fresh-process memory probes include runtime,
JIT, loading, and validation; Python peak RSS likewise includes imports and
post-validation. Neither is a solver-only memory measurement.

## Validation and interpretation

`validate_upstream.py` checks independent GF(2) elimination, predicted swap
ranks, actual swap/reverse updates, and fixed-RNG direct versus incremental
annealing trajectories. Tiny fixtures are exhaustively optimized under the
same balanced capacities. Their optimum gaps do not establish optimality on
large circuit graphs. The baseline audit independently reconstructs GraphML
declaration-order vertex mapping, topology hashes, rank, matching, and edge cut.

`audit_comparison.py` checks every saved incumbent and final membership, all
seed coverage, strict timestamp eligibility, and native completion status. A
small subset is rerun with uninstrumented upstream code to check observation
transparency. The Julia `score` mode independently rescores every distinct
published membership with QuantumHamlets kernels.

Figures retain complete named families and observed minimum-to-maximum ranges.
Ranges are not confidence intervals. Initial/reduced pairs, evolution stages,
and related circuit sizes are not independent population samples. No hypothesis
tests or universal performance guarantees are inferred from this corpus.

Matching and edge cut are secondary measurements of the same returned
memberships, not separately optimized outputs. Lower rank does not imply lower
matching cost. METIS is not included in this strict-capacity contest: the older
study used its 3% tolerance. Filtering that earlier study would not establish an
equal-policy comparison.

## Reproduction

Run Julia from the package root with the existing parent environment
(`--project=..`). Do not add GraphIO or experiment dependencies to the production
package. Python requires >=3.11 and NumPy>=2.3.5; matplotlib is used for figures.
The completed run records its exact executable and versions. No existing
dependency was installed or upgraded for this study.

Collection used the bundled Python 3.12.14 with NumPy 2.3.5. Static figures used
an existing research Python 3.10.6 environment with NumPy 2.2.6 and matplotlib
3.10.9; its exact executable is in `figures_v2/figure_manifest.json`. Document
creation/rendering used the bundled document runtime. These are separate
environments; plotting did not rerun any partitioner.

The local upstream checkout is ignored by Git. Recreate it with:

```sh
git clone https://github.com/OpenQuantumComputing/min-cutrank.git experiments/min_cutrank_comparison/upstream
git -C experiments/min_cutrank_comparison/upstream checkout 86c1d8ff5d9b901983d9ad2254c8df0651e0219d
```

Choose a new empty output directory for every new study. In the commands below,
replace `RUN_DIR` with that directory and `python3` with a suitable interpreter:

```sh
julia --startup-file=no --threads=1 --project=.. experiments/min_cutrank_comparison/julia_baselines.jl export RUN_DIR
python3 experiments/min_cutrank_comparison/prepare_synthetic.py RUN_DIR
julia --startup-file=no --threads=1 --project=.. experiments/min_cutrank_comparison/julia_baselines.jl run RUN_DIR
python3 experiments/min_cutrank_comparison/run_annealing.py collect RUN_DIR --workers 2
python3 experiments/min_cutrank_comparison/assemble_results.py RUN_DIR
julia --startup-file=no --threads=1 --project=.. experiments/min_cutrank_comparison/julia_baselines.jl score RUN_DIR RUN_DIR/memberships.tsv RUN_DIR/julia_rescoring.tsv
python3 experiments/min_cutrank_comparison/audit_comparison.py RUN_DIR
python3 experiments/min_cutrank_comparison/figures.py RUN_DIR
```

To reproduce the predeclared schedule supplement, run `run_sensitivity.py
prepare RUN_DIR` while the main collection is still in progress, then
`run_sensitivity.py collect RUN_DIR` after it completes, followed by
`run_sensitivity.py summarize RUN_DIR`. Preparation refuses to choose its subset
after the main run finishes; collection refuses to overlap the main annealing
workers. All commands use the same Python interpreter as the main collection.

Collection can resume from existing immutable task JSON only with the original
input, baseline, protocol, and source hashes. Table writers refuse overwrites.
Plotting and report generation use saved data and do not rerun partitioners.
The report specification and figure sources are retained alongside the results.

## Sources

- [Pinned upstream implementation](https://github.com/OpenQuantumComputing/min-cutrank/tree/86c1d8ff5d9b901983d9ad2254c8df0651e0219d)
- [Annealing implementation](https://github.com/OpenQuantumComputing/min-cutrank/blob/86c1d8ff5d9b901983d9ad2254c8df0651e0219d/src/min-cutrank/cut_rank_annealing.py)
- [Default test schedule](https://github.com/OpenQuantumComputing/min-cutrank/blob/86c1d8ff5d9b901983d9ad2254c8df0651e0219d/src/min-cutrank/test_annealing.py)
- [Earlier GraphML family study](../../resources/graphml_family_plots_README.md)
