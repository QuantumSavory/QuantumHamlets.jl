#!/usr/bin/env python3
"""Derive report counts from final saved tables without running partitioners."""
import argparse
import csv
import json
import statistics
from collections import Counter
from pathlib import Path


def read_table(path):
    with path.open() as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    run = args.run_dir
    inputs = read_table(run / "inputs.tsv")
    results = read_table(run / "results.tsv")
    summaries = read_table(run / "summary.tsv")
    comparisons = read_table(run / "comparisons.tsv")
    status = read_table(run / "status.tsv")
    assert len(status) == 2010 and len(inputs) == 67
    assert len(results) == 13735
    meta = {r["id"]: r for r in inputs}
    methods = ("bury", "sqrt_bury", "random_sa", "bury_sa", "sqrt_sa")
    lookup = {(r["id"], r["method"], r["view"], r["budget_seconds"]): r for r in summaries}
    result_lookup = {(r["id"], r["method"], r["seed"], r["view"], r["budget_seconds"]): r for r in results}

    groups = {
        "all_circuits": [r["id"] for r in inputs if r["collection"].startswith("graphml_")],
        "all_synthetic": [r["id"] for r in inputs if not r["collection"].startswith("graphml_")],
        "other_circuits": [r["id"] for r in inputs if r["collection"] in ("graphml_initial", "graphml_reduced")
                           and r["family"] not in ("gf_multiplier", "toffoli", "barenco_toffoli")],
    }
    for collection in sorted({r["collection"] for r in inputs}):
        groups[collection] = [r["id"] for r in inputs if r["collection"] == collection]
    for family in sorted({r["family"] for r in inputs}):
        groups[family] = [r["id"] for r in inputs if r["family"] == family]

    payload = {"overview": json.loads((run / "overview.json").read_text()), "groups": {}, "graph_rows": []}
    for name, ids in groups.items():
        ids = set(ids)
        group = {"graphs": len(ids), "comparisons": {}, "hybrid_changes": {}, "native_completion": {}}
        for view, budget in (("native", ""), ("incumbent", "30.0")):
            for metric in ("rank", "matching", "edge_cut"):
                for method in ("bury", "sqrt_bury", "bury_sa", "sqrt_sa"):
                    found = [r for r in comparisons if r["id"] in ids and r["method"] == method
                             and r["view"] == view and r["metric"] == metric and r["budget_seconds"] == budget]
                    assert len(found) == len(ids)
                    group["comparisons"][f"{method}/{view}/{metric}"] = dict(Counter(r["outcome"] for r in found))
        for method, base_method in (("bury_sa", "bury"), ("sqrt_sa", "sqrt_bury")):
            for view, budget in (("native", ""), ("incumbent", "30.0")):
                counts = Counter()
                differences = []
                for graph_id in ids:
                    for seed in range(10):
                        row = result_lookup[graph_id, method, str(seed), view, budget]
                        base = result_lookup[graph_id, base_method, "-1" if base_method == "bury" else str(seed), "native", ""]
                        if row["rank"] == "":
                            counts["unavailable"] += 1
                        else:
                            delta = int(row["rank"]) - int(base["rank"])
                            differences.append(delta)
                            counts["lower" if delta < 0 else "higher" if delta > 0 else "tied"] += 1
                group["hybrid_changes"][f"{method}/{view}"] = {
                    "counts": dict(counts), "minimum_rank_change": min(differences) if differences else None,
                    "maximum_rank_change": max(differences) if differences else None,
                }
            group["native_completion"][method] = dict(Counter(r["status"] for r in status if r["id"] in ids and r["method"] == method))
        group["native_completion"]["random_sa"] = dict(Counter(r["status"] for r in status if r["id"] in ids and r["method"] == "random_sa"))
        payload["groups"][name] = group

    for graph in inputs:
        graph_row = {k: graph[k] for k in ("id", "collection", "family", "label", "n", "m")}
        for method in methods:
            for view, budget in (("native", ""), ("incumbent", "30.0")):
                row = lookup[graph["id"], method, view, budget]
                graph_row[f"{method}/{view}"] = {k: row[k] for k in (
                    "total", "valid", "rank_median", "rank_min", "rank_max", "matching_median",
                    "edge_cut_median", "candidate_seconds_median", "solve_seconds_median")}
        payload["graph_rows"].append(graph_row)

    payload["budget_availability"] = {}
    for budget in ("0.1", "1.0", "5.0", "30.0"):
        payload["budget_availability"][budget] = {}
        for method in methods:
            selected = [r for r in summaries if r["method"] == method and r["view"] == "incumbent" and r["budget_seconds"] == budget]
            payload["budget_availability"][budget][method] = {
                "full_graphs": sum(int(r["valid"]) == int(r["total"]) for r in selected),
                "available_replicates": sum(int(r["valid"]) for r in selected),
                "total_replicates": sum(int(r["total"]) for r in selected),
            }

    timings = read_table(run / "timing_summary.tsv")
    payload["warmed_timing_medians"] = {}
    for method in ("bury", "sqrt_bury"):
        values = [float(r["median_wall_seconds"]) for r in timings if r["method"] == method]
        payload["warmed_timing_medians"][method] = {"n_keys": len(values), "minimum": min(values),
            "median_across_keys": statistics.median(values), "maximum": max(values)}

    dest = run / "report" / "report_statistics.json"
    dest.parent.mkdir(exist_ok=True)
    dest.write_text(json.dumps(payload, indent=2) + "\n")
    print(dest)
    print(json.dumps({name: payload["groups"][name] for name in ("all_circuits", "all_synthetic", "other_circuits")}, indent=2))


if __name__ == "__main__":
    main()
