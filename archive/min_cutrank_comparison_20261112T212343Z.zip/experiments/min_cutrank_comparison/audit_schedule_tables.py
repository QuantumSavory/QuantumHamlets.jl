#!/usr/bin/env python3
"""Reconstruct sensitivity comparison tables independently from saved task JSON."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path


def table(path):
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("main_run_dir", type=Path)
    args = parser.parse_args()
    parent = args.main_run_dir.resolve()
    run = parent / "schedule_sensitivity"
    output = run / "schedule_table_audit.json"
    if output.exists():
        raise SystemExit(f"Refusing to overwrite {output}")
    protocol = json.loads((run / "protocol.json").read_text())
    summary_json = json.loads((run / "schedule_comparison.json").read_text())
    inputs = {row["id"]: row for row in table(run / "inputs.tsv")}
    main_inputs = {row["id"]: row for row in table(parent / "inputs.tsv")}
    counts = Counter()

    def check(condition, kind):
        if not condition:
            raise AssertionError(kind)
        counts[kind] += 1

    check(protocol["parent_tasks_complete_at_freeze"] < protocol["parent_planned_tasks"], "freeze_before_main_completion")
    check(hashlib.sha256((parent / "protocol.json").read_bytes()).hexdigest()
          == protocol["parent_protocol_sha256"], "parent_protocol_hash")
    check(set(inputs) == set(protocol["selected_ids"]) and len(inputs) == 11, "selected_graph_coverage")
    check(protocol["annealing_seeds"] == [0, 1, 2] and protocol["sweeps"] == 100, "sensitivity_schedule")
    for graph_id, entry in inputs.items():
        check(entry == main_inputs[graph_id], "unchanged_manifest_row")
        check((run / "edges" / f"{graph_id}.tsv").read_bytes()
              == (parent / "edges" / f"{graph_id}.tsv").read_bytes(), "unchanged_topology")
    parent_baselines = {(row["id"], row["method"], row["seed"]): row for row in table(parent / "baselines.tsv")}
    for row in table(run / "baselines.tsv"):
        check(row == parent_baselines[(row["id"], row["method"], row["seed"])], "unchanged_baseline_row")

    def tasks(directory):
        return {(task["id"], task["method"], task["seed"]): task
                for path in (directory / "tasks").glob("*.json")
                for task in [json.loads(path.read_text())]}

    first_tasks, second_tasks = tasks(parent), tasks(run)
    expected = {}
    groups = defaultdict(Counter)
    totals = defaultdict(Counter)
    for key, second in second_tasks.items():
        first = first_tasks[key]
        check(first["initial_labels"] == second["initial_labels"], "same_initial_membership")
        check(first["initial_rank"] == second["initial_rank"], "same_initial_rank")
        check(first["initializer_seconds"] == second["initializer_seconds"], "same_initializer_time_charge")
        pairs = [("native_final", first.get("final"), second.get("final"))]
        for budget in protocol["budgets_seconds"]:
            candidates = []
            for task in (first, second):
                eligible = [event for event in task["incumbent_events"] if event["seconds"] <= budget]
                # Independent reconstruction chooses the minimum rank available,
                # with first-best tie handling, instead of reading saved snapshots.
                candidates.append(min(eligible, key=lambda event: event["rank"]) if eligible else None)
            pairs.append((f"incumbent_{budget:g}s", *candidates))
        for comparison, one, two in pairs:
            delta = two["rank"] - one["rank"] if one is not None and two is not None else None
            outcome = "unavailable" if delta is None else "lower" if delta < 0 else "higher" if delta > 0 else "tied"
            graph_id, method, seed = key
            entry = inputs[graph_id]
            expected[key + (comparison,)] = (one, two, delta, outcome, first["status"], second["status"])
            groups[(entry["collection"], entry["family"], method, comparison)][outcome] += 1
            totals[(method, comparison)][outcome] += 1
    differences = table(run / "schedule_differences.tsv")
    actual_keys = [(row["id"], row["method"], int(row["seed"]), row["comparison"]) for row in differences]
    check(len(actual_keys) == len(set(actual_keys)) == len(expected) == 495, "unique_difference_row_count")
    check(set(actual_keys) == set(expected), "complete_difference_coverage")
    for key, row in zip(actual_keys, differences):
        one, two, delta, outcome, first_status, second_status = expected[key]
        entry = inputs[row["id"]]
        check(row["collection"] == entry["collection"] and row["family"] == entry["family"]
              and row["n"] == entry["n"], "difference_graph_metadata")
        check(row["main_status"] == first_status and row["sensitivity_status"] == second_status,
              "difference_status")
        for prefix, candidate in (("main", one), ("sensitivity", two)):
            check(row[prefix + "_rank"] == (str(candidate["rank"]) if candidate else ""), "difference_rank")
            check((float(row[prefix + "_candidate_seconds"]) == candidate["seconds"])
                  if candidate else row[prefix + "_candidate_seconds"] == "", "difference_time")
        check(row["sensitivity_minus_main"] == (str(delta) if delta is not None else ""), "difference_delta")
        check(row["outcome"] == outcome, "difference_outcome")
    summaries = table(run / "schedule_summary.tsv")
    check(len(summaries) == len(groups), "family_summary_row_count")
    for row in summaries:
        key = (row["collection"], row["family"], row["method"], row["comparison"])
        count = groups[key]
        for outcome in ("lower", "tied", "higher", "unavailable"):
            check(int(row[outcome]) == count[outcome], "family_summary_count")
        check(int(row["total"]) == sum(count.values()), "family_summary_total")
    check(len(summary_json["comparisons"]) == len(totals), "overall_summary_row_count")
    for row in summary_json["comparisons"]:
        count = totals[(row["method"], row["comparison"])]
        for outcome in ("lower", "tied", "higher", "unavailable"):
            check(row.get(outcome, 0) == count[outcome], "overall_summary_count")
    check(summary_json["statuses"] == dict(Counter(task["status"] for task in second_tasks.values())),
          "overall_status_counts")
    check(summary_json["native_available_pairs"] == sum(
        1 for key, value in expected.items() if key[-1] == "native_final" and value[2] is not None),
        "native_pair_denominator")
    result = dict(status="passed", assertions=sum(counts.values()), counts=dict(counts),
                  paired_tasks=len(second_tasks), reconstructed_differences=len(expected),
                  files_sha256={name: hashlib.sha256((run / name).read_bytes()).hexdigest()
                                for name in ("schedule_differences.tsv", "schedule_summary.tsv", "schedule_comparison.json")})
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
