"""Append the predeclared synthetic families to a fresh GraphML export."""
import argparse
import csv
import hashlib
import json
import random
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    manifest = args.run_dir / "inputs.tsv"
    with manifest.open() as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fields, existing = reader.fieldnames, list(reader)
    assert len(existing) == 45 and all(r["collection"].startswith("graphml_") for r in existing)
    additions = []

    def add(graph_id, family, label, parameter, n, edges, definition):
        path = args.run_dir / "edges" / f"{graph_id}.tsv"
        with path.open("x") as handle:
            handle.write("u\tv\n")
            for u, v in sorted(edges):
                assert 0 <= u < v < n
                handle.write(f"{u}\t{v}\n")
        source = json.dumps(definition, sort_keys=True)
        additions.append(dict(id=graph_id, collection="synthetic", family=family,
            label=label, parameter=parameter, n=n, m=len(edges),
            source_sha256=hashlib.sha256(source.encode()).hexdigest(),
            edge_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        return dict(id=graph_id, definition=definition)

    definitions = []
    for side in (4, 6, 8, 10):
        edges = []
        for row in range(side):
            for col in range(side):
                u = row * side + col
                if col + 1 < side: edges.append((u, u + 1))
                if row + 1 < side: edges.append((u, u + side))
        definitions.append(add(f"synthetic__grid_{side}", "grid", f"{side}x{side}", side,
            side * side, edges, dict(generator="square_grid", side=side)))
    for n in (40, 80, 120):
        for c in (2, 5):
            for seed in (1000, 1001, 1002):
                rng = random.Random(seed)
                edges = [(u, v) for u in range(n) for v in range(u + 1, n) if rng.random() < c / n]
                definitions.append(add(f"synthetic__er_n{n}_c{c}_s{seed}", f"er_c{c}",
                    f"n={n}, c={c}, graph seed={seed}", n, n, edges,
                    dict(generator="Erdos_Renyi_Gnp", n=n, p=c / n, c=c,
                         graph_seed=seed, rng="Python random.Random", connected_conditioning=False)))
    with manifest.open("a") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writerows(additions)
    with (args.run_dir / "synthetic_definitions.json").open("x") as handle:
        json.dump(definitions, handle, indent=2)
    print(f"Appended {len(additions)} synthetic graphs; total {len(existing) + len(additions)}")


if __name__ == "__main__":
    main()
