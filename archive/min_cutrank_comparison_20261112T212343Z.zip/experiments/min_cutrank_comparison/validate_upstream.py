#!/usr/bin/env python3
"""Independent correctness checks for the pinned min-cutrank implementation.

This script imports upstream code without modifying it.  The rank oracle uses
integer row bitsets and one-sided XOR elimination, rather than upstream's
two-sided matrix/basis updates.  Validation time is not benchmark time.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path
import random
import sys
import time
from collections import Counter
import xml.etree.ElementTree as ET


def gf2_cut_rank(adjacency: list[list[int]], flags: list[bool]) -> int:
    """Rank of A[flags, !flags] over GF(2), without NumPy or upstream code."""
    columns = [i for i, flag in enumerate(flags) if not flag]
    pivots: dict[int, int] = {}
    for i, flag in enumerate(flags):
        if not flag:
            continue
        row = sum((adjacency[i][j] & 1) << k for k, j in enumerate(columns))
        while row:
            pivot = row.bit_length() - 1
            if pivot in pivots:
                row ^= pivots[pivot]
            else:
                pivots[pivot] = row
                break
    return len(pivots)


def adjacency_from_edges(n: int, edges) -> list[list[int]]:
    adjacency = [[0] * n for _ in range(n)]
    for i, j in edges:
        adjacency[i][j] = adjacency[j][i] = 1
    return adjacency


def graph_from_mask(n: int, mask: int) -> list[list[int]]:
    return adjacency_from_edges(
        n,
        (edge for bit, edge in enumerate(itertools.combinations(range(n), 2))
         if (mask >> bit) & 1),
    )


def random_graph(n: int, probability: float, rng: random.Random):
    return adjacency_from_edges(
        n, (edge for edge in itertools.combinations(range(n), 2)
            if rng.random() < probability)
    )


def flags_from_rows(n: int, rows) -> list[bool]:
    flags = [False] * n
    for row in rows:
        flags[row] = True
    return flags


def exact_balanced_rank(adjacency):
    """Enumerate all floor-size row sets, including complementary duplicates."""
    n = len(adjacency)
    best_rank = n
    best_flags = None
    evaluated = 0
    for rows in itertools.combinations(range(n), n // 2):
        flags = flags_from_rows(n, rows)
        rank = gf2_cut_rank(adjacency, flags)
        evaluated += 1
        if rank < best_rank:
            best_rank, best_flags = rank, flags
    return best_rank, best_flags, evaluated


def cut_matching_size(adjacency, flags):
    """Independent bipartite maximum cardinality matching by augmenting BFS."""
    rows = [i for i, flag in enumerate(flags) if flag]
    columns = [i for i, flag in enumerate(flags) if not flag]
    neighbors = {row: [col for col in columns if adjacency[row][col]] for row in rows}
    match_left = {}
    match_right = {}
    for root in rows:
        queue = [root]
        reached_left = {root}
        previous_right = {}
        unmatched_column = None
        for row in queue:
            for col in neighbors[row]:
                if col in previous_right:
                    continue
                previous_right[col] = row
                if col not in match_right:
                    unmatched_column = col
                    break
                next_row = match_right[col]
                if next_row not in reached_left:
                    reached_left.add(next_row)
                    queue.append(next_row)
            if unmatched_column is not None:
                break
        if unmatched_column is not None:
            col = unmatched_column
            while True:
                row = previous_right[col]
                old_col = match_left.get(row)
                match_left[row] = col
                match_right[col] = row
                if old_col is None:
                    break
                col = old_col
    return len(match_left)


def audit_baselines(output_dir: Path):
    """Validate every saved Julia baseline against independent Python kernels."""
    target = output_dir / "baseline_audit.json"
    if target.exists():
        raise SystemExit(f"Refusing to overwrite {target}")
    repository = Path(__file__).resolve().parents[2]
    with (output_dir / "inputs.tsv").open() as stream:
        inputs = list(csv.DictReader(stream, delimiter="\t"))
    with (output_dir / "baselines.tsv").open() as stream:
        baselines = list(csv.DictReader(stream, delimiter="\t"))
    counts = Counter()

    def check(condition, category, context):
        if not condition:
            raise AssertionError(f"{context}: {category}")
        counts[category] += 1

    known_ids = {row["id"] for row in inputs}
    check(len(known_ids) == len(inputs), "unique_input_ids", "manifest")
    check(all(row["id"] in known_ids for row in baselines), "known_result_ids", "results")
    for entry in inputs:
        graph_id = entry["id"]
        n, m = int(entry["n"]), int(entry["m"])
        path = output_dir / "edges" / f"{graph_id}.tsv"
        check(hashlib.sha256(path.read_bytes()).hexdigest() == entry["edge_sha256"],
              "edge_hash", graph_id)
        with path.open() as stream:
            edges = [(int(row["u"]), int(row["v"]))
                     for row in csv.DictReader(stream, delimiter="\t")]
        check(len(edges) == m and len(set(edges)) == m, "unique_edge_count", graph_id)
        check(all(0 <= u < v < n for u, v in edges), "canonical_edges", graph_id)
        if entry["collection"].startswith("graphml_"):
            source = repository / "resources" / entry["collection"] / (entry["label"] + ".graphml")
            check(hashlib.sha256(source.read_bytes()).hexdigest() == entry["source_sha256"],
                  "source_hash", graph_id)
            xml = ET.parse(source)
            nodes = [node.attrib["id"] for node in xml.findall(".//{*}node")]
            index = {node_id: i for i, node_id in enumerate(nodes)}
            xml_edges = {
                tuple(sorted((index[edge.attrib["source"]], index[edge.attrib["target"]])))
                for edge in xml.findall(".//{*}edge")
            }
            check(len(nodes) == n and len(index) == n, "xml_nodes", graph_id)
            check(xml_edges == set(edges), "xml_topology_and_mapping", graph_id)
        adjacency = adjacency_from_edges(n, edges)
        records = [row for row in baselines if row["id"] == graph_id]
        expected_keys = {("bury", -1)} | {("sqrt_bury", seed) for seed in range(10)}
        actual_keys = [(row["method"], int(row["seed"])) for row in records]
        check(set(actual_keys) == expected_keys and len(actual_keys) == len(expected_keys),
              "method_seed_coverage", graph_id)
        for row in records:
            context = f"{graph_id}/{row['method']}/{row['seed']}"
            labels = row["labels"]
            check(len(labels) == n and set(labels) <= {"0", "1"}, "membership_bits", context)
            flags = [bit == "1" for bit in labels]
            sizes = sorted([sum(flags), n - sum(flags)])
            check(sizes == [n // 2, n - n // 2], "exact_capacity", context)
            check(int(row["n_true"]) == sum(flags)
                  and int(row["n_false"]) == n - sum(flags), "reported_sizes", context)
            rank = gf2_cut_rank(adjacency, flags)
            matching = cut_matching_size(adjacency, flags)
            edge_cut = sum(flags[u] != flags[v] for u, v in edges)
            check(rank == int(row["rank"]), "independent_gf2_rank", context)
            check(matching == int(row["matching"]), "independent_cardinality_matching", context)
            check(edge_cut == int(row["edge_cut"]), "independent_edge_cut", context)
            check(0 <= rank <= matching <= edge_cut, "cost_order", context)
            check(float(row["solve_seconds"]) > 0 and int(row["bytes"]) >= 0,
                  "timing_allocation_domain", context)
    result = {
        "status": "passed", "assertions": sum(counts.values()),
        "graphs": len(inputs), "memberships": len(baselines),
        "counts": dict(counts),
        "inputs_sha256": hashlib.sha256((output_dir / "inputs.tsv").read_bytes()).hexdigest(),
        "baselines_sha256": hashlib.sha256((output_dir / "baselines.tsv").read_bytes()).hexdigest(),
        "scope": "All memberships, exact capacities, GF(2) ranks, cardinality matchings, edge cuts, source and topology hashes, XML declaration-order mappings, method/seed coverage",
        "limitations": "Does not independently rerun BURY or reproduce its timings",
    }
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def tiny_fixtures():
    yield "empty8", adjacency_from_edges(8, []), 0
    yield "complete8", adjacency_from_edges(8, itertools.combinations(range(8), 2)), 1
    yield "path9", adjacency_from_edges(9, ((i, i + 1) for i in range(8))), 1
    yield "cycle9", adjacency_from_edges(9, ((i, (i + 1) % 9) for i in range(9))), None
    yield "star10", adjacency_from_edges(10, ((0, i) for i in range(1, 10))), 1
    yield "ladder10", adjacency_from_edges(
        10,
        [(i, i + 5) for i in range(5)]
        + [(i, i + 1) for i in range(4)]
        + [(i + 5, i + 6) for i in range(4)]), None
    yield "two_triangles6", adjacency_from_edges(
        6, [(0, 1), (1, 2), (0, 2), (3, 4), (4, 5), (3, 5)]), 0
    for n, probability, seed in [(10, 0.2, 111), (11, 0.35, 222), (12, 0.5, 333)]:
        yield f"random{n}_seed{seed}", random_graph(n, probability, random.Random(seed)), None


def validate_exact_grids(output_dir: Path):
    """Supplement: exhaustively establish the two smallest requested grid optima."""
    target = output_dir / "grid_exact_validation.json"
    if target.exists():
        raise SystemExit(f"Refusing to overwrite {target}")
    results = []
    for dimension in (3, 4):
        n = dimension * dimension
        edges = []
        for row in range(dimension):
            for column in range(dimension):
                vertex = row * dimension + column
                if row + 1 < dimension:
                    edges.append((vertex, vertex + dimension))
                if column + 1 < dimension:
                    edges.append((vertex, vertex + 1))
        adjacency = adjacency_from_edges(n, edges)
        rank, flags, evaluated = exact_balanced_rank(adjacency)
        if rank != dimension:
            raise AssertionError(f"Unexpected exact grid rank {dimension}: {rank}")
        results.append({
            "id": f"grid{dimension}x{dimension}", "n": n, "m": len(edges),
            "exact_rank": rank, "partitions_enumerated": evaluated,
            "row_size": n // 2, "column_size": n - n // 2,
            "optimal_flags": "".join(str(int(flag)) for flag in flags),
            "edges": edges,
        })
    result = {
        "status": "passed",
        "method": "Complete enumeration of all floor-size vertex subsets with independent GF(2) bitset elimination",
        "scope": "Only the 3x3 and 4x4 unweighted square grids; not a proof for larger grids",
        "partitions_enumerated": sum(row["partitions_enumerated"] for row in results),
        "results": results,
    }
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "partitions_enumerated": result["partitions_enumerated"],
                      "grid_ranks": [row["exact_rank"] for row in results]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream", type=Path, required=True,
                        help="Pinned upstream checkout root")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--grids-only", action="store_true",
                        help="Write the separate exhaustive 3x3 and 4x4 grid supplement")
    parser.add_argument("--audit-baselines", action="store_true",
                        help="Validate saved Julia memberships and scores independently")
    args = parser.parse_args()
    upstream = args.upstream.resolve()
    output_dir = args.output_dir.resolve()
    source_dir = upstream / "src" / "min-cutrank"
    if not (source_dir / "graph_partition.py").is_file():
        raise SystemExit(f"Missing upstream source in {source_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    if args.grids_only:
        validate_exact_grids(output_dir)
        return
    if args.audit_baselines:
        audit_baselines(output_dir)
        return
    output_names = ["upstream_validation.json", "upstream_validation.txt",
                    "tiny_exact.tsv", "tiny_fixtures.json"]
    for name in output_names:
        if (output_dir / name).exists():
            raise SystemExit(f"Refusing to overwrite {output_dir / name}")
    sys.path.insert(0, str(source_dir))
    import numpy as np
    from graph_partition import GraphPartition
    from swap_rank_calculator import (all_swap_cut_ranks, row_swap_cut_ranks,
                                      single_swap_cut_rank)
    from cut_rank_annealing import (cut_rank_annealing_direct,
                                   cut_rank_annealing_row_formula)

    started = time.perf_counter()
    counts = Counter()
    context = "startup"

    def check(condition, category, detail=""):
        if not condition:
            raise AssertionError(f"{context}: {category}: {detail}")
        counts[category] += 1

    def check_partition(partition, expected_flags, expected_rank):
        n = len(expected_flags)
        check(partition.row_flag == expected_flags, "membership")
        check(sorted(partition.rows) == [i for i in range(n) if expected_flags[i]],
              "rows")
        check(sorted(partition.columns) == [i for i in range(n) if not expected_flags[i]],
              "columns")
        check(len(partition.rows) == sum(expected_flags), "capacity")
        check(len(partition.rows) + len(partition.columns) == n, "coverage")
        check(partition.cut_rank == expected_rank, "independent_rank",
              f"upstream={partition.cut_rank}, oracle={expected_rank}")
        check(len(partition.base_rows) == expected_rank
              and len(partition.base_columns) == expected_rank, "basis_size")
        check(set(partition.base_rows).isdisjoint(partition.free_rows)
              and set(partition.base_rows) | set(partition.free_rows) == set(partition.rows),
              "row_basis_partition")
        check(set(partition.base_columns).isdisjoint(partition.free_columns)
              and set(partition.base_columns) | set(partition.free_columns) == set(partition.columns),
              "column_basis_partition")

    def validate_fixture(adjacency, flags):
        saved_adjacency = [row[:] for row in adjacency]
        rank = gf2_cut_rank(adjacency, flags)
        check(rank == gf2_cut_rank(adjacency, [not f for f in flags]), "complement_rank")
        partition = GraphPartition(adjacency, flags)
        check_partition(partition, flags, rank)
        n = len(flags)
        all_ranks = [[-1] * n for _ in range(n)]
        all_swap_cut_ranks(partition, all_ranks)
        rows = partition.rows[:]
        columns = partition.columns[:]
        for row in rows:
            row_ranks = [-1] * n
            row_swap_cut_ranks(partition, row, row_ranks)
            for column in columns:
                swapped = flags[:]
                swapped[row], swapped[column] = False, True
                expected = gf2_cut_rank(adjacency, swapped)
                check(abs(expected - rank) <= 2, "swap_rank_bound")
                check(all_ranks[row][column] == expected, "all_swap_formula")
                check(row_ranks[column] == expected, "row_swap_formula")
                check(single_swap_cut_rank(partition, row, column) == expected,
                      "single_swap_formula")
                partition.apply_swap(row, column)
                check_partition(partition, swapped, expected)
                partition.apply_swap(column, row)
                check_partition(partition, flags, rank)
                counts["tested_swaps"] += 1
        check(adjacency == saved_adjacency, "input_graph_ownership")
        counts["partition_fixtures"] += 1

    # Exhaustive graph enumeration is separate from the sampled larger suite.
    for n in range(2, 5):
        for mask in range(1 << (n * (n - 1) // 2)):
            adjacency = graph_from_mask(n, mask)
            counts["exhaustive_graphs"] += 1
            for k in range(1, n):
                for rows in itertools.combinations(range(n), k):
                    context = f"exhaustive n={n} mask={mask} rows={rows}"
                    validate_fixture(adjacency, flags_from_rows(n, rows))
        print(f"Exhaustive n={n} passed", flush=True)

    fixture_rng = random.Random(20261112)
    for n in range(5, 17):
        for sample in range(20):
            probability = [0.0, 0.1, 0.3, 0.5, 1.0][sample % 5]
            adjacency = random_graph(n, probability, fixture_rng)
            k = n // 2 if sample % 2 == 0 else fixture_rng.randrange(1, n)
            flags = flags_from_rows(n, fixture_rng.sample(range(n), k))
            context = f"sampled n={n} sample={sample} p={probability}"
            validate_fixture(adjacency, flags)
            counts["sampled_graphs"] += 1
    print("Sampled graph and swap validation passed", flush=True)

    class CheckedPartition(GraphPartition):
        """Read-only observation of each accepted upstream swap."""

        def __init__(self, adjacency, flags):
            super().__init__(adjacency, flags)
            self.initial_capacity = sum(flags)
            self.trace = [(tuple(self.row_flag), self.cut_rank)]
            check_partition(self, flags, gf2_cut_rank(adjacency, flags))

        def apply_swap(self, row, column):
            super().apply_swap(row, column)
            check(sum(self.row_flag) == self.initial_capacity, "trace_capacity")
            check_partition(self, self.row_flag[:],
                            gf2_cut_rank(self.adjacencies, self.row_flag))
            self.trace.append((tuple(self.row_flag), self.cut_rank))
            counts["observed_annealing_swaps"] += 1

    orientation_witness = None
    final_above_incumbent_witness = None
    temperatures = np.linspace(1.0, 0.1, 10)
    for n in range(2, 15):
        for graph_seed in range(3):
            adjacency = random_graph(n, [0.1, 0.4, 0.8][graph_seed],
                                     random.Random(5000 + 100 * n + graph_seed))
            flags = flags_from_rows(n, random.Random(6000 + n).sample(range(n), n // 2))
            for seed in range(5):
                context = f"annealing n={n} graph_seed={graph_seed} rng_seed={seed}"
                direct = CheckedPartition(adjacency, flags)
                random.seed(seed)
                cut_rank_annealing_direct(direct, temperatures, False)
                direct_rng = random.getstate()
                formula = CheckedPartition(adjacency, flags)
                random.seed(seed)
                cut_rank_annealing_row_formula(formula, temperatures, False)
                formula_rng = random.getstate()
                check(direct.trace == formula.trace, "direct_incremental_trajectory")
                check(direct.row_flag == formula.row_flag, "direct_incremental_final_membership")
                check(direct_rng == formula_rng, "direct_incremental_rng_state")
                stock = GraphPartition(adjacency, flags)
                random.seed(seed)
                cut_rank_annealing_row_formula(stock, temperatures, False)
                check(stock.row_flag == formula.row_flag
                      and stock.cut_rank == formula.cut_rank, "observation_preserves_final")
                check(random.getstate() == formula_rng, "observation_preserves_rng")
                counts["annealing_comparisons"] += 1
                incumbent = min(rank for _, rank in formula.trace)
                if final_above_incumbent_witness is None and formula.cut_rank > incumbent:
                    final_above_incumbent_witness = {
                        "n": n, "graph_seed": graph_seed, "rng_seed": seed,
                        "initial_flags": "".join(str(int(f)) for f in flags),
                        "final_rank": formula.cut_rank, "best_rank": incumbent,
                        "edges": [[i, j] for i in range(n) for j in range(i + 1, n)
                                  if adjacency[i][j]],
                    }
                if orientation_witness is None and n % 2:
                    reverse = GraphPartition(adjacency, [not f for f in flags])
                    random.seed(seed)
                    cut_rank_annealing_row_formula(reverse, temperatures, False)
                    if formula.cut_rank != reverse.cut_rank:
                        orientation_witness = {
                            "n": n, "graph_seed": graph_seed, "rng_seed": seed,
                            "floor_rows_rank": formula.cut_rank,
                            "ceil_rows_rank": reverse.cut_rank,
                            "edges": [[i, j] for i in range(n) for j in range(i + 1, n)
                                      if adjacency[i][j]],
                            "floor_initial_flags": "".join(str(int(f)) for f in flags),
                        }
    print("Fixed-RNG direct and incremental trajectories passed", flush=True)

    exact_rows = []
    exact_fixtures = []
    for name, adjacency, known_optimum in tiny_fixtures():
        n = len(adjacency)
        context = f"exact optimum {name}"
        optimum, optimum_flags, evaluated = exact_balanced_rank(adjacency)
        if known_optimum is not None:
            check(optimum == known_optimum, "known_optimum")
        counts["exact_optimum_partitions"] += evaluated
        counts["exact_optimum_graphs"] += 1
        edges = [[i, j] for i in range(n) for j in range(i + 1, n) if adjacency[i][j]]
        exact_fixtures.append({
            "id": name, "n": n, "edges": edges, "exact_rank": optimum,
            "exact_flags": "".join(str(int(f)) for f in optimum_flags),
            "partitions_enumerated": evaluated,
        })
        for seed in range(10):
            context = f"tiny annealing {name} seed={seed}"
            random.seed(seed)
            flags = [True] * (n // 2) + [False] * (n - n // 2)
            random.shuffle(flags)
            partition = CheckedPartition(adjacency, flags)
            cut_rank_annealing_row_formula(partition, temperatures, False)
            incumbent = min(rank for _, rank in partition.trace)
            check(incumbent >= optimum, "exact_lower_bound_incumbent")
            check(partition.cut_rank >= optimum, "exact_lower_bound_final")
            exact_rows.append({
                "id": name, "n": n, "m": len(edges), "seed": seed,
                "exact_rank": optimum, "initial_rank": partition.trace[0][1],
                "final_rank": partition.cut_rank, "incumbent_rank": incumbent,
                "final_gap": partition.cut_rank - optimum,
                "incumbent_gap": incumbent - optimum,
                "partitions_enumerated": evaluated,
                "final_flags": "".join(str(int(f)) for f in partition.row_flag),
            })
    print("Tiny exact-optimum validation passed", flush=True)

    # Category counters ending in graphs/fixtures/etc are observations, not assertions.
    observation_categories = {
        "tested_swaps", "partition_fixtures", "exhaustive_graphs", "sampled_graphs",
        "observed_annealing_swaps", "annealing_comparisons", "exact_optimum_partitions",
        "exact_optimum_graphs",
    }
    assertions = sum(value for key, value in counts.items() if key not in observation_categories)
    source_hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(source_dir.glob("*.py"))
    }
    result = {
        "status": "passed", "assertions": assertions,
        "counts": dict(sorted(counts.items())),
        "seconds": time.perf_counter() - started,
        "python": sys.version, "numpy": np.__version__,
        "upstream_path": str(upstream), "source_sha256": source_hashes,
        "rank_oracle": "Independent integer-bitset one-sided XOR Gaussian elimination over GF(2)",
        "scope": "All labeled simple graphs n=2..4 and all nonempty row sets; 240 seeded graph/partition fixtures n=5..16; 195 direct/incremental fixed-RNG comparisons; 10 exact optimum fixtures and 100 annealing runs",
        "orientation_witness": orientation_witness,
        "final_above_incumbent_witness": final_above_incumbent_witness,
        "tiny_final_above_optimum": sum(row["final_gap"] > 0 for row in exact_rows),
        "tiny_incumbent_above_optimum": sum(row["incumbent_gap"] > 0 for row in exact_rows),
    }
    (output_dir / "upstream_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    (output_dir / "tiny_fixtures.json").write_text(json.dumps(exact_fixtures, indent=2) + "\n")
    with (output_dir / "tiny_exact.tsv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(exact_rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(exact_rows)
    summary = (
        f"PASS: {assertions:,} assertions\n"
        f"Scope: {result['scope']}\n"
        f"Partition fixtures: {counts['partition_fixtures']:,}\n"
        f"Swap predictions and apply/reverse pairs: {counts['tested_swaps']:,}\n"
        f"Observed accepted annealing swaps: {counts['observed_annealing_swaps']:,}\n"
        f"Exact balanced partitions enumerated: {counts['exact_optimum_partitions']:,}\n"
        f"Tiny runs above exact optimum, final/incumbent: "
        f"{result['tiny_final_above_optimum']}/100, {result['tiny_incumbent_above_optimum']}/100\n"
        f"Runtime: {result['seconds']:.3f} seconds (validation, not benchmark timing)\n"
        "Every returned cut rank and every tested swap was checked with an independent GF(2) oracle.\n"
        "Direct/incremental trajectories and final RNG states agree. Observation subclass preserves stock behavior.\n"
        "Main-study memberships require separate end-to-end validation. These checks do not establish universal correctness.\n"
    )
    (output_dir / "upstream_validation.txt").write_text(summary)
    print(summary, end="", flush=True)


if __name__ == "__main__":
    main()
