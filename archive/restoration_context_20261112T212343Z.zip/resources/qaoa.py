# Taken from Graphix documentation on QAOA example
# https://graphix.readthedocs.io/en/latest/gallery/qaoa.html
# Modified slightly

"""
QAOA
====

Here we generate and optimize pattern for QAOA circuit.

"""

# %%
from __future__ import annotations

import networkx as nx
import numpy as np
import sys

from graphix import Circuit

rng = np.random.default_rng()

n = int(sys.argv[1])
#n = 100
xi = rng.random(int(n*(n-1)/2))
theta = rng.random(n)
g = nx.complete_graph(n)
circuit = Circuit(n)
for i, (u, v) in enumerate(g.edges):
    circuit.cnot(u, v)
    circuit.rz(v, xi[i])
    circuit.cnot(u, v)
for v in g.nodes:
    circuit.rx(v, theta[v])

# %%
# transpile and get the graph state

pattern = circuit.transpile().pattern
pattern.standardize()
pattern.shift_signals()
#pattern.draw_graph(flow_from_pattern=False)


# %%
# perform Pauli measurements and plot the new (minimal) graph to perform the same quantum computation

pattern.perform_pauli_measurements()
#pattern.draw_graph(flow_from_pattern=False)


G = pattern.extract_graph()
filename = "qaoa_"+str(n)+".graphml"
filepath = "/Users/micciche/Research/QuantumInfo23/JuliaProjects/QuantumHamlet/QAOAgraphs/"
nx.write_graphml_lxml(G, filepath+filename)
# %%
# finally, simulate the QAOA circuit

#out_state = pattern.simulate_pattern()
#state = circuit.simulate_statevector().statevec
#print("overlap of states: ", np.abs(np.dot(state.psi.flatten().conjugate(), out_state.psi.flatten())))
# sphinx_gallery_thumbnail_number = 2

# %%
