using QuantumHamlets
using QuantumHamlets: quantumLand
using QuantumClifford
using Graphs
using GraphMakie
using CairoMakie
using Colors
using Statistics
using IGraphs
using Metis

using GraphIO.GraphML
using EzXML

include("comparison_scores.jl")

function grid_graph(numVertices)
    a = sqrt(numVertices)
    b = floor(a) |> Int
    while numVertices%b != 0
        b -= 1
    end

    a = numVertices÷b
    return Graphs.grid([a,b])
end

# Plots performance of METIS versus BURY on compiled graph states provided by a path to a directory with graphml files
function deterministic_comparison(graph_generator; name="", maxHamlets=8)
    pt = 4/3
    f = Figure(size=(900, 700),px_per_unit = 6.0, fontsize = 21pt, yticks = [0, 20, 100, 200, 300, 400])
    ax = f[1,1] = Axis(f[1,1],  xlabel="Vertices in Graph", ylabel=COMPARISON_OBJECTIVE_LABEL,title="METIS vs BURY on "*name)
    
    bury_costs = [[] for _ in 1:maxHamlets]
    metis_costs = [[] for _ in 1:maxHamlets]

    for i in 24:100
        g = graph_generator(i*i)
        n = nv(g)
        for k in 2:maxHamlets
            if n%k != 0
                continue
            end

            bury_reg = QuantumHamlets.bury_k(g, k)
            bury_cost = comparison_score(g, bury_reg, k)

            push!(bury_costs[k], [n,bury_cost])

            metis_reg = Dict()
            metis_part = Metis.partition(g,k)
            for a in eachindex(metis_part)
                metis_reg[a] = metis_part[a]
            end

            metis_cost = comparison_score(g, metis_reg, k)
            push!(metis_costs[k], [n,metis_cost])
        end
    end

    wong_colors = Makie.wong_colors()
    for k in 2:maxHamlets
        sort!(bury_costs[k], by = x -> x[1])
        sort!(metis_costs[k], by = x -> x[1])
        x_bury = [data[1] for data in bury_costs[k]]
        y_bury = [data[2] for data in bury_costs[k]]

        x_metis = [data[1] for data in metis_costs[k]]
        y_metis = [data[2] for data in metis_costs[k]]

        scatterlines!(ax, x_bury, y_bury, color=wong_colors[(k%7)+1], marker=:circle, markersize=12)
        scatterlines!(ax, x_metis, y_metis, color=wong_colors[(k%7)+1], marker=:xcross, markersize=12)

        lines!(ax, [0,0], [0,0], label=string(k), color=wong_colors[(k%7)+1], linewidth = 12)
    end

    scatter!(ax, [0], [0], label="METIS", color=:gray, marker=:xcross, markersize= 16)
    scatter!(ax, [0], [0], label="BURY", color=:gray, marker=:circle, markersize = 16)

    f[1,2] = Legend(f, ax, "Number of\nHamlets")
    return f, bury_costs, metis_costs
end

#f_grid, bury_costs, metis_costs = deterministic_comparison(grid_graph, name="Grid Graphs")