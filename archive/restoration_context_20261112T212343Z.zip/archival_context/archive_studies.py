"""One-time preservation of completed QuantumHamlets research; no deletion here."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, stat, subprocess, zipfile

ROOT = Path('/Users/micciche/Research/QuantumInfo23/JuliaProjects/QuantumHamlets.jl')
STAGE = Path(__file__).resolve().parent
STAMP = STAGE.name.removeprefix('quantumhamlets_archive_')
OUT = ROOT / 'archive'
BACKUP = ROOT.parent / 'QuantumHamlets-archive-backup' / STAMP
OUT.mkdir(exist_ok=True)
BACKUP.mkdir(parents=True, exist_ok=False)
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
TRACKED = set(subprocess.check_output(['git','ls-files'], cwd=ROOT, text=True).splitlines())

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def excluded(path):
    return any(x in {'__pycache__', '.CondaPkg', '.DS_Store'} for x in path.parts) or path.suffix == '.pyc'

def collect(roots):
    files, dirs, omitted = {}, set(), []
    for rel in roots:
        path = ROOT / rel
        assert path.exists(), path
        candidates = [path] if path.is_file() else [path, *path.rglob('*')]
        for p in candidates:
            name = p.relative_to(ROOT).as_posix()
            if excluded(p.relative_to(ROOT)):
                omitted.append(name)
            elif p.is_symlink():
                raise RuntimeError(f'Handle symlink explicitly before proceeding: {p}')
            elif p.is_file(): files[name] = p
            elif p.is_dir(): dirs.add(name)
    return files, sorted(dirs), sorted(set(omitted))

study_names = [p.name for p in sorted((ROOT/'experiments').iterdir()) if p.is_dir()]
studies = {name: ['experiments/' + name] for name in study_names}
studies['graphml_comparisons'] = [
    'resources/graphml_plots.jl', 'resources/graphml_plots_validation.jl',
    'resources/graphml_plots_README.md', 'resources/run_graphml_plots.py',
    'resources/graphml_family_analysis.jl', 'resources/graphml_family_analysis_validation.jl',
    'resources/graphml_family_plots.jl', 'resources/graphml_family_plots_README.md',
    'resources/run_graphml_family_plots.py',
    'resources/figs/graphml_comparison', 'resources/figs/graphml_families']
studies['historical_docs'] = ['docs/' + n for n in (
    'bipartition_range_handoff.md', 'bipartition_range_review.md', 'bug_audit.md',
    'library_experiments_handoff.md', 'revision_proposal.md')]

# Historical commits are preserved in a bundle; uncommitted files are captured
# separately below. Neither changes this checkout's history or index.
bundle = STAGE/'repository.bundle'
subprocess.run(['git','bundle','create',str(bundle),'--all'],cwd=ROOT,check=True)
subprocess.run(['git','bundle','verify',str(bundle)],cwd=ROOT,check=True,capture_output=True)
context_roots = ['src','test','Project.toml','Manifest.toml','CondaPkg.toml','README.md','.gitignore']
context_roots += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'docs').glob('*.md'))]
context_roots += ['resources/graphml_initial','resources/graphml_reduced','resources/graphml_evolution',
                  'resources/QAOAgraphs_mini/qaoa_30.graphml','resources/QAOAgraphs_mini/qaoa_60.graphml']
context_roots += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'resources').iterdir())
                  if p.is_file() and p.suffix in {'.jl','.py','.md'}]
context_roots += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'resources/figs').iterdir()) if p.is_file()]
studies['restoration_context'] = context_roots
extra_context = {
    'archival_context/repository.bundle': bundle,
    'archival_context/git_status_before.txt': STAGE/'git_status_before.txt',
    'archival_context/git_diff_before.patch': STAGE/'git_diff_before.patch',
    'archival_context/archive_studies.py': Path(__file__),
    'archival_context/parent_environment/Project.toml': ROOT.parent/'Project.toml',
    'archival_context/parent_environment/Manifest.toml': ROOT.parent/'Manifest.toml',
}

summaries = []
for name, roots in studies.items():
    files, dirs, omitted = collect(roots)
    if name == 'restoration_context': files.update(extra_context)
    entries = []
    for rel, path in sorted(files.items()):
        info = path.stat()
        entries.append(dict(path=rel, bytes=info.st_size, sha256=digest(path),
                            mode=stat.S_IMODE(info.st_mode), mtime_ns=info.st_mtime_ns,
                            tracked_at_archival=rel in TRACKED))
    manifest = dict(study=name, archived_utc=STAMP, package_head_at_archival=HEAD,
        original_roots=roots, directories=dirs, files=entries, excluded_paths=omitted,
        exclusions='Only __pycache__, .CondaPkg, .DS_Store, and .pyc. Nested upstream .git is retained.',
        context_note='Archival-time source/environment is not a substitute for original-run provenance. Original snapshots/logs remain inside study archives.')
    target = OUT / f'{name}_{STAMP}.zip'
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for directory in dirs:
            zi = zipfile.ZipInfo(directory + '/')
            zi.create_system = 3
            zi.external_attr = (stat.S_IFDIR | 0o755) << 16
            z.writestr(zi, b'')
        for entry in entries: z.write(files[entry['path']], entry['path'])
        z.writestr('ARCHIVE_MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    restore = STAGE/'restored'/name
    restore.mkdir(parents=True)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert len([x for x in z.infolist() if not x.is_dir()]) == len(entries) + 1
        z.extractall(restore)
    for entry in entries:
        restored = restore / entry['path']
        assert restored.stat().st_size == entry['bytes']
        assert digest(restored) == entry['sha256']
        assert digest(files[entry['path']]) == entry['sha256'], 'Source changed during archival'
        os.chmod(restored, entry['mode'])
    for directory in dirs: assert (restore/directory).is_dir()
    copied = BACKUP/target.name
    shutil.copy2(target, copied)
    sha = digest(target)
    assert digest(copied) == sha
    summary = dict(study=name, archive=target.name, files=len(entries),
                   original_bytes=sum(e['bytes'] for e in entries), archive_bytes=target.stat().st_size,
                   sha256=sha, backup=str(copied), restore_directory=str(restore),
                   full_extraction_hash_check='passed', original_roots=roots, excluded_paths=omitted)
    summaries.append(summary)
    print(f'{name}: {len(entries)} files, {target.stat().st_size/2**20:.2f} MiB, restored and verified', flush=True)

checksums = ''.join(f"{s['sha256']}  {s['archive']}\n" for s in summaries)
(OUT/'SHA256SUMS').write_text(checksums)
(BACKUP/'SHA256SUMS').write_text(checksums)
report = dict(timestamp_utc=STAMP, source_head=HEAD, backup_directory=str(BACKUP),
              archives=summaries, status='all_archives_and_backups_verified_before_cleanup')
(OUT/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
(STAGE/'archive_inventory.json').write_text(json.dumps(report, indent=2)+'\n')
print('Backup:', BACKUP, flush=True)
